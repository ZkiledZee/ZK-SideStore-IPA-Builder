# ZK Agent V1

SwiftUI iPhone shell for an autonomous opportunity agent.

## Included
- Custom animated agent core driven by actual app state
- Agent modes: WATCH / ASSIST / AUTOPILOT
- Mission and opportunity tracking
- Approval queue
- Revenue/spend ledger
- Local JSON persistence
- Backend URL/token settings for future live agent service
- GitHub Actions unsigned IPA build
- Bundle ID: `com.zk.agent`

## Important V1 behaviour
This build does not pretend it is searching the live internet. The local cycle demonstrates the state machine and generates a clearly-labelled placeholder opportunity. Connect a real backend/search service before treating opportunities as live/verified.

## Build
Push the complete contents of this folder to a GitHub repository on the `main` branch. Open **Actions → Build Unsigned IPA → Run workflow**. Download the `ZKAgent-v1.0.0-unsigned` artifact when successful.

For SideStore/other signing workflows, sign the unsigned IPA using your normal builder/signing process.
