import Foundation

enum AgentMode: String, Codable, CaseIterable {
    case watch = "WATCH"
    case assist = "ASSIST"
    case autopilot = "AUTOPILOT"
}

enum AgentState: String, Codable {
    case idle, scanning, researching, comparing, building, waitingApproval, success, warning
}

struct ActivityEvent: Identifiable, Codable, Hashable {
    let id: UUID
    let timestamp: Date
    let title: String
    let detail: String
    let state: AgentState

    init(id: UUID = UUID(), timestamp: Date = Date(), title: String, detail: String, state: AgentState) {
        self.id = id
        self.timestamp = timestamp
        self.title = title
        self.detail = detail
        self.state = state
    }
}

struct Opportunity: Identifiable, Codable, Hashable {
    let id: UUID
    var title: String
    var category: String
    var score: Int
    var startupCost: Double
    var estimatedRevenue: Double
    var evidence: String
    var status: String
}

struct Mission: Identifiable, Codable, Hashable {
    let id: UUID
    var title: String
    var objective: String
    var progress: Double
    var status: String
    var createdAt: Date
}

struct ApprovalRequest: Identifiable, Codable, Hashable {
    let id: UUID
    var title: String
    var reason: String
    var estimatedCost: Double
    var risk: String
    var createdAt: Date
}

struct LedgerEntry: Identifiable, Codable, Hashable {
    let id: UUID
    let timestamp: Date
    let type: String
    let amount: Double
    let note: String
}
