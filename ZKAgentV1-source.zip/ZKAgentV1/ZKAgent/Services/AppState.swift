import Foundation
import SwiftUI

@MainActor
final class AppState: ObservableObject {
    @Published var mode: AgentMode = .assist
    @Published var state: AgentState = .idle
    @Published var isRunning = false
    @Published var revenue: Double = 0
    @Published var spend: Double = 0
    @Published var opportunities: [Opportunity] = []
    @Published var missions: [Mission] = []
    @Published var approvals: [ApprovalRequest] = []
    @Published var activity: [ActivityEvent] = []
    @Published var ledger: [LedgerEntry] = []
    @Published var backendURL: String = ""
    @Published var apiToken: String = ""

    private var loopTask: Task<Void, Never>?
    private let storage = LocalStore()

    init() {
        load()
        if missions.isEmpty {
            missions = [Mission(id: UUID(), title: "Zero-Cost Income", objective: "Find legitimate £0-startup opportunities with the fastest path to revenue.", progress: 0, status: "Ready", createdAt: Date())]
        }
        if activity.isEmpty {
            activity = [ActivityEvent(title: "Agent ready", detail: "No background claims: actions shown here come from the local engine or your connected backend.", state: .idle)]
        }
    }

    func toggleAgent() {
        isRunning ? stop() : start()
    }

    func start() {
        guard !isRunning else { return }
        isRunning = true
        log("Mission started", "Beginning local opportunity cycle.", .scanning)
        loopTask = Task { [weak self] in
            guard let self else { return }
            await self.runCycle()
        }
    }

    func stop() {
        isRunning = false
        state = .idle
        loopTask?.cancel()
        loopTask = nil
        log("Agent paused", "Automation stopped safely.", .idle)
        save()
    }

    private func runCycle() async {
        let phases: [(AgentState, String, String)] = [
            (.scanning, "Scanning", "Checking configured opportunity sources."),
            (.researching, "Researching", "Reviewing evidence and startup requirements."),
            (.comparing, "Comparing", "Scoring by cost, speed, demand and automation potential."),
            (.building, "Preparing", "Building the next action plan for the best candidate.")
        ]

        for phase in phases {
            guard isRunning, !Task.isCancelled else { return }
            state = phase.0
            log(phase.1, phase.2, phase.0)
            try? await Task.sleep(nanoseconds: 1_000_000_000)
        }

        guard isRunning else { return }
        let sample = Opportunity(id: UUID(), title: "Local service lead qualification", category: "Lead generation", score: 82, startupCost: 0, estimatedRevenue: 40, evidence: "V1 local engine placeholder. Connect backend tools to replace this with verified live evidence.", status: "Needs backend verification")
        opportunities.insert(sample, at: 0)

        if mode == .watch {
            state = .success
            log("Opportunity recorded", sample.title, .success)
        } else {
            state = .waitingApproval
            approvals.insert(ApprovalRequest(id: UUID(), title: "Verify & prepare outreach", reason: "A candidate opportunity reached the action threshold.", estimatedCost: 0, risk: "Low", createdAt: Date()), at: 0)
            log("Approval required", "Candidate reached action threshold.", .waitingApproval)
        }
        save()
        isRunning = false
    }

    func approve(_ request: ApprovalRequest) {
        approvals.removeAll { $0.id == request.id }
        log("Approved", request.title, .building)
        if let idx = missions.indices.first {
            missions[idx].progress = min(1, missions[idx].progress + 0.2)
            missions[idx].status = "In progress"
        }
        save()
    }

    func reject(_ request: ApprovalRequest) {
        approvals.removeAll { $0.id == request.id }
        log("Rejected", request.title, .warning)
        save()
    }

    func addRevenue(_ amount: Double, note: String) {
        guard amount > 0 else { return }
        revenue += amount
        ledger.insert(LedgerEntry(id: UUID(), timestamp: Date(), type: "Revenue", amount: amount, note: note), at: 0)
        log("Revenue recorded", String(format: "£%.2f — %@", amount, note), .success)
        save()
    }

    func addExpense(_ amount: Double, note: String) {
        guard amount > 0 else { return }
        spend += amount
        ledger.insert(LedgerEntry(id: UUID(), timestamp: Date(), type: "Expense", amount: -amount, note: note), at: 0)
        save()
    }

    func saveSettings() { save() }

    private func log(_ title: String, _ detail: String, _ state: AgentState) {
        self.state = state
        activity.insert(ActivityEvent(title: title, detail: detail, state: state), at: 0)
        if activity.count > 100 { activity = Array(activity.prefix(100)) }
    }

    private func load() {
        guard let snapshot = storage.load() else { return }
        mode = snapshot.mode
        revenue = snapshot.revenue
        spend = snapshot.spend
        opportunities = snapshot.opportunities
        missions = snapshot.missions
        approvals = snapshot.approvals
        activity = snapshot.activity
        ledger = snapshot.ledger
        backendURL = snapshot.backendURL
        apiToken = snapshot.apiToken
    }

    private func save() {
        storage.save(Snapshot(mode: mode, revenue: revenue, spend: spend, opportunities: opportunities, missions: missions, approvals: approvals, activity: activity, ledger: ledger, backendURL: backendURL, apiToken: apiToken))
    }
}

struct Snapshot: Codable {
    let mode: AgentMode
    let revenue: Double
    let spend: Double
    let opportunities: [Opportunity]
    let missions: [Mission]
    let approvals: [ApprovalRequest]
    let activity: [ActivityEvent]
    let ledger: [LedgerEntry]
    let backendURL: String
    let apiToken: String
}

final class LocalStore {
    private var url: URL? {
        FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first?.appendingPathComponent("zkagent.json")
    }
    func save(_ snapshot: Snapshot) {
        guard let url, let data = try? JSONEncoder().encode(snapshot) else { return }
        try? data.write(to: url, options: .atomic)
    }
    func load() -> Snapshot? {
        guard let url, let data = try? Data(contentsOf: url) else { return nil }
        return try? JSONDecoder().decode(Snapshot.self, from: data)
    }
}
