import SwiftUI

struct SettingsView: View {
    @EnvironmentObject var app: AppState
    var body: some View {
        NavigationStack {
            Form {
                Section("Autonomy") {
                    Picker("Mode", selection: $app.mode) {
                        ForEach(AgentMode.allCases, id: \.self) { Text($0.rawValue).tag($0) }
                    }
                    Text("WATCH only records. ASSIST asks before actions. AUTOPILOT is intended for approved low-risk tools only.").font(.caption).foregroundStyle(.secondary)
                }
                Section("Backend connection") {
                    TextField("https://your-backend.example", text: $app.backendURL)
                        .textInputAutocapitalization(.never).keyboardType(.URL)
                    SecureField("API token", text: $app.apiToken)
                    Button("Save connection") { app.saveSettings() }
                    Text("V1 runs locally without claiming live web actions. Add your backend here when the live agent service is deployed.").font(.caption).foregroundStyle(.secondary)
                }
                Section("Safety") {
                    Label("No wallet private keys stored", systemImage: "lock.shield")
                    Label("Spending requires explicit approval", systemImage: "hand.raised")
                    Label("Activity feed reflects real engine events", systemImage: "checkmark.seal")
                }
            }.navigationTitle("Settings")
        }
    }
}
