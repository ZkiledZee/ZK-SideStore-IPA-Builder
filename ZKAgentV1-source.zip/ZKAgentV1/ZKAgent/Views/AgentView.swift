import SwiftUI

struct AgentView: View {
    @EnvironmentObject var app: AppState
    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(spacing: 22) {
                    HStack {
                        VStack(alignment: .leading, spacing: 4) {
                            Text("ZK AGENT").font(.title2.bold())
                            Text(app.isRunning ? "ONLINE" : "READY").font(.caption.weight(.semibold)).foregroundStyle(.secondary)
                        }
                        Spacer()
                        Text(app.mode.rawValue).font(.caption.bold()).padding(.horizontal, 10).padding(.vertical, 6).background(.white.opacity(0.08), in: Capsule())
                    }

                    AgentCore(state: app.state, running: app.isRunning)
                        .frame(height: 230)

                    Button(action: app.toggleAgent) {
                        Label(app.isRunning ? "Pause Agent" : "Run Agent", systemImage: app.isRunning ? "pause.fill" : "play.fill")
                            .frame(maxWidth: .infinity).padding(.vertical, 14).font(.headline)
                    }
                    .buttonStyle(.borderedProminent)
                    .tint(.white)
                    .foregroundStyle(.black)

                    HStack(spacing: 12) {
                        StatCard(title: "Revenue", value: app.revenue, prefix: "£")
                        StatCard(title: "Opportunities", text: "\(app.opportunities.count)")
                        StatCard(title: "Approvals", text: "\(app.approvals.count)")
                    }

                    if !app.approvals.isEmpty {
                        VStack(alignment: .leading, spacing: 12) {
                            Text("Needs approval").font(.headline)
                            ForEach(app.approvals) { request in ApprovalCard(request: request) }
                        }
                    }

                    VStack(alignment: .leading, spacing: 12) {
                        Text("Live activity").font(.headline)
                        ForEach(app.activity.prefix(12)) { event in
                            HStack(alignment: .top, spacing: 12) {
                                Circle().fill(.white.opacity(0.75)).frame(width: 7, height: 7).padding(.top, 7)
                                VStack(alignment: .leading, spacing: 3) {
                                    Text(event.title).font(.subheadline.weight(.semibold))
                                    Text(event.detail).font(.caption).foregroundStyle(.secondary)
                                    Text(event.timestamp, style: .time).font(.caption2).foregroundStyle(.tertiary)
                                }
                                Spacer()
                            }
                        }
                    }
                }.padding()
            }
            .navigationTitle("")
        }
    }
}

struct AgentCore: View {
    let state: AgentState
    let running: Bool
    @State private var pulse = false
    var body: some View {
        ZStack {
            ForEach(0..<3, id: \.self) { i in
                Circle().stroke(.white.opacity(0.12 - Double(i) * 0.02), lineWidth: 1)
                    .scaleEffect(pulse && running ? 1.1 + CGFloat(i) * 0.09 : 0.85 + CGFloat(i) * 0.06)
                    .opacity(pulse && running ? 0.1 : 0.8)
                    .animation(.easeInOut(duration: 1.6 + Double(i) * 0.3).repeatForever(autoreverses: true), value: pulse)
            }
            Circle().fill(.white.opacity(0.04)).frame(width: 118, height: 118)
            Circle().stroke(.white.opacity(0.7), lineWidth: 2).frame(width: 88, height: 88)
                .rotationEffect(.degrees(running ? 360 : 0))
                .animation(.linear(duration: 5).repeatForever(autoreverses: false), value: running)
            VStack(spacing: 6) {
                Image(systemName: icon).font(.system(size: 28, weight: .medium))
                Text(label).font(.caption.bold())
            }
        }
        .onAppear { pulse = true }
    }
    private var label: String {
        switch state { case .idle: "IDLE"; case .scanning: "SCANNING"; case .researching: "RESEARCH"; case .comparing: "COMPARE"; case .building: "BUILDING"; case .waitingApproval: "APPROVAL"; case .success: "COMPLETE"; case .warning: "CHECK" }
    }
    private var icon: String {
        switch state { case .idle: "circle.dotted"; case .scanning: "dot.radiowaves.left.and.right"; case .researching: "doc.text.magnifyingglass"; case .comparing: "slider.horizontal.3"; case .building: "hammer"; case .waitingApproval: "hand.raised"; case .success: "checkmark"; case .warning: "exclamationmark.triangle" }
    }
}

struct StatCard: View {
    let title: String
    var value: Double? = nil
    var text: String? = nil
    var prefix: String = ""
    var body: some View {
        VStack(alignment: .leading, spacing: 7) {
            Text(title).font(.caption).foregroundStyle(.secondary)
            Text(text ?? String(format: "%@%.2f", prefix, value ?? 0)).font(.headline.bold()).lineLimit(1).minimumScaleFactor(0.7)
        }.frame(maxWidth: .infinity, alignment: .leading).padding(12).background(.white.opacity(0.055), in: RoundedRectangle(cornerRadius: 16))
    }
}

struct ApprovalCard: View {
    @EnvironmentObject var app: AppState
    let request: ApprovalRequest
    var body: some View {
        VStack(alignment: .leading, spacing: 9) {
            Text(request.title).font(.subheadline.bold())
            Text(request.reason).font(.caption).foregroundStyle(.secondary)
            HStack { Text("Cost £\(request.estimatedCost, specifier: "%.2f")"); Spacer(); Text("Risk \(request.risk)") }.font(.caption2).foregroundStyle(.secondary)
            HStack {
                Button("Reject") { app.reject(request) }.buttonStyle(.bordered)
                Button("Approve") { app.approve(request) }.buttonStyle(.borderedProminent).tint(.white).foregroundStyle(.black)
            }
        }.padding().background(.white.opacity(0.06), in: RoundedRectangle(cornerRadius: 18))
    }
}
