import SwiftUI

struct MoneyView: View {
    @EnvironmentObject var app: AppState
    @State private var amount = ""
    @State private var note = ""
    var body: some View {
        NavigationStack {
            List {
                Section("Performance") {
                    LabeledContent("Revenue", value: String(format: "£%.2f", app.revenue))
                    LabeledContent("Spend", value: String(format: "£%.2f", app.spend))
                    LabeledContent("Net", value: String(format: "£%.2f", app.revenue - app.spend))
                }
                Section("Record real revenue") {
                    TextField("Amount", text: $amount).keyboardType(.decimalPad)
                    TextField("Note", text: $note)
                    Button("Add revenue") {
                        let cleaned = amount.replacingOccurrences(of: ",", with: ".")
                        if let value = Double(cleaned) { app.addRevenue(value, note: note.isEmpty ? "Manual revenue" : note); amount = ""; note = "" }
                    }
                }
                Section("Ledger") {
                    if app.ledger.isEmpty { Text("Nothing recorded yet.").foregroundStyle(.secondary) }
                    ForEach(app.ledger) { entry in
                        HStack { VStack(alignment: .leading) { Text(entry.note); Text(entry.timestamp, style: .date).font(.caption2).foregroundStyle(.secondary) }; Spacer(); Text(String(format: "%@£%.2f", entry.amount >= 0 ? "+" : "", entry.amount)).font(.subheadline.bold()) }
                    }
                }
            }.navigationTitle("Money")
        }
    }
}
