import SwiftUI

struct LeadRow: View {
    let lead: Lead

    var icon: String {
        let c = lead.category.lowercased()
        if c.contains("roof") { return "house.lodge.fill" }
        if c.contains("heat") || c.contains("boiler") { return "flame.fill" }
        if c.contains("drain") || c.contains("plumb") { return "drop.fill" }
        if c.contains("electric") { return "bolt.fill" }
        return "wrench.and.screwdriver.fill"
    }

    var body: some View {
        HStack(spacing: 12) {
            ZStack {
                Circle().fill(Color.zkCyan.opacity(0.10)).frame(width: 50, height: 50)
                Circle().stroke(Color.zkCyan.opacity(0.7)).frame(width: 50, height: 50)
                Image(systemName: icon).foregroundStyle(Color.zkCyan)
            }
            VStack(alignment: .leading, spacing: 4) {
                Text(lead.title).font(.subheadline.bold()).lineLimit(1)
                HStack(spacing: 6) {
                    Circle().fill(lead.score >= 80 ? Color.zkCyan : .orange).frame(width: 6, height: 6)
                    Text("\(lead.city) • \(lead.ageText)").font(.caption).foregroundStyle(.secondary)
                }
                HStack(spacing: 6) {
                    Image(systemName: "checkmark.shield.fill")
                    Text(lead.phoneVerified ? "Phone verified" : "Customer confirmed open")
                }
                .font(.caption2).foregroundStyle(Color.zkCyan)
            }
            Spacer()
            VStack(alignment: .trailing, spacing: 6) {
                Text("\(lead.score)").font(.title3.bold()).foregroundStyle(Color.zkCyan)
                Text("SCORE").font(.system(size: 8, weight: .bold)).foregroundStyle(.secondary)
                if let value = lead.valueText { Text(value).font(.caption2).foregroundStyle(.secondary) }
            }
        }
        .padding(12)
        .background(Color.white.opacity(0.035), in: RoundedRectangle(cornerRadius: 18))
        .overlay(RoundedRectangle(cornerRadius: 18).stroke(Color.zkCyan.opacity(0.14)))
    }
}
