import SwiftUI

extension Color {
    static let zkCyan = Color(red: 0.08, green: 0.95, blue: 0.88)
    static let zkBlue = Color(red: 0.05, green: 0.48, blue: 1.0)
    static let zkPanel = Color(red: 0.025, green: 0.075, blue: 0.11)
    static let zkInk = Color(red: 0.005, green: 0.025, blue: 0.045)
}

struct NeonPanel<Content: View>: View {
    @ViewBuilder var content: Content
    var body: some View {
        content
            .padding(14)
            .background(.ultraThinMaterial.opacity(0.32), in: RoundedRectangle(cornerRadius: 20, style: .continuous))
            .overlay(RoundedRectangle(cornerRadius: 20).stroke(Color.zkCyan.opacity(0.18), lineWidth: 1))
    }
}

struct LivePill: View {
    var online: Bool
    var body: some View {
        HStack(spacing: 7) {
            Circle().fill(online ? Color.zkCyan : .orange).frame(width: 8, height: 8)
                .shadow(color: online ? .zkCyan : .orange, radius: 8)
            Text(online ? "LIVE" : "CONNECT")
                .font(.caption.bold())
        }
        .padding(.horizontal, 12).padding(.vertical, 8)
        .background(Color.white.opacity(0.04), in: Capsule())
        .overlay(Capsule().stroke(Color.zkCyan.opacity(0.35)))
    }
}
