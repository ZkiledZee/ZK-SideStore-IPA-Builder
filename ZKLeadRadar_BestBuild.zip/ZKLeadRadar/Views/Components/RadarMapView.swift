import SwiftUI
import MapKit

struct RadarMapView: View {
    let leads: [Lead]
    @State private var position: MapCameraPosition = .region(.init(
        center: .init(latitude: 53.72, longitude: -1.65),
        span: .init(latitudeDelta: 0.72, longitudeDelta: 0.95)
    ))
    @State private var sweep = false

    var body: some View {
        ZStack {
            Map(position: $position, interactionModes: [.pan, .zoom]) {
                ForEach(leads) { lead in
                    Annotation(lead.city, coordinate: lead.coordinate, anchor: .center) {
                        VStack(spacing: 3) {
                            ZStack {
                                Circle().fill(Color.zkCyan.opacity(0.22)).frame(width: 32, height: 32)
                                Circle().stroke(Color.zkCyan, lineWidth: 2).frame(width: 20, height: 20)
                                Circle().fill(Color.white).frame(width: 6, height: 6)
                            }
                            .shadow(color: .zkCyan, radius: 10)
                            Text(lead.city)
                                .font(.caption2.bold())
                                .foregroundStyle(.white)
                                .padding(.horizontal, 6).padding(.vertical, 3)
                                .background(.black.opacity(0.72), in: Capsule())
                        }
                    }
                }
            }
            .mapStyle(.standard(elevation: .flat, pointsOfInterest: .excludingAll, showsTraffic: false))
            .saturation(0.15)
            .contrast(1.25)
            .colorMultiply(Color(red: 0.20, green: 0.58, blue: 0.72))

            GeometryReader { geo in
                let d = min(geo.size.width, geo.size.height) * 0.78
                ZStack {
                    ForEach([0.34, 0.58, 0.82, 1.0], id: \.self) { factor in
                        Circle().stroke(Color.zkCyan.opacity(0.20), lineWidth: 1)
                            .frame(width: d * factor, height: d * factor)
                    }
                    Rectangle().fill(Color.zkCyan.opacity(0.13)).frame(width: 1, height: d)
                    Rectangle().fill(Color.zkCyan.opacity(0.13)).frame(width: d, height: 1)
                    RadarSweep()
                        .fill(AngularGradient(colors: [.clear, Color.zkBlue.opacity(0.05), Color.zkCyan.opacity(0.42), .clear], center: .center, startAngle: .degrees(0), endAngle: .degrees(70)))
                        .frame(width: d, height: d)
                        .rotationEffect(.degrees(sweep ? 360 : 0))
                        .animation(.linear(duration: 3.4).repeatForever(autoreverses: false), value: sweep)
                }
                .frame(maxWidth: .infinity, maxHeight: .infinity)
                .allowsHitTesting(false)
            }
        }
        .clipShape(RoundedRectangle(cornerRadius: 24, style: .continuous))
        .overlay(RoundedRectangle(cornerRadius: 24).stroke(Color.zkCyan.opacity(0.30), lineWidth: 1))
        .onAppear { sweep = true }
    }
}

private struct RadarSweep: Shape {
    func path(in rect: CGRect) -> Path {
        var path = Path()
        let c = CGPoint(x: rect.midX, y: rect.midY)
        path.move(to: c)
        path.addArc(center: c, radius: min(rect.width, rect.height) / 2, startAngle: .degrees(-90), endAngle: .degrees(-20), clockwise: false)
        path.closeSubpath()
        return path
    }
}
