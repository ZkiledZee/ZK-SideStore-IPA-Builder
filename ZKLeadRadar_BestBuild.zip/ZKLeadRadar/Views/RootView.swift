import SwiftUI

struct RootView: View {
    @State private var tab = 0
    var body: some View {
        TabView(selection: $tab) {
            HomeView().tabItem { Label("Home", systemImage: "house.fill") }.tag(0)
            LeadsView().tabItem { Label("Leads", systemImage: "list.bullet.rectangle") }.tag(1)
            RadarView().tabItem { Label("Radar", systemImage: "scope") }.tag(2)
            BuyersView().tabItem { Label("Buyers", systemImage: "person.2.fill") }.tag(3)
            SettingsView().tabItem { Label("Settings", systemImage: "gearshape.fill") }.tag(4)
        }
        .tint(.zkCyan)
    }
}
