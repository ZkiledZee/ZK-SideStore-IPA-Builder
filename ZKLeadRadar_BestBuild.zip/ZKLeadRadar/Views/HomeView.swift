import SwiftUI

struct HomeView: View {
    @EnvironmentObject var store: LeadStore
    private let cities = ["All", "Bradford", "Leeds", "Huddersfield", "Halifax", "Wakefield"]

    var body: some View {
        ScrollView(showsIndicators: false) {
            VStack(spacing: 16) {
                header
                statusCard
                RadarMapView(leads: store.filteredLeads)
                    .frame(height: 350)

                metrics
                cityStrip
                freshLeads
            }
            .padding(.horizontal, 16)
            .padding(.top, 8)
            .padding(.bottom, 120)
        }
        .background(background)
        .refreshable { await store.refresh() }
        .task { store.start() }
        .onDisappear { store.stop() }
    }

    private var header: some View {
        HStack {
            ZStack {
                Circle().stroke(Color.zkCyan, lineWidth: 2).frame(width: 42, height: 42)
                Image(systemName: "location.north.circle.fill").font(.title2).foregroundStyle(.zkCyan)
            }
            VStack(alignment: .leading, spacing: 1) {
                Text("ZK Lead Radar").font(.title2.bold())
                Text("West Yorkshire live acquisition").font(.caption).foregroundStyle(.secondary)
            }
            Spacer()
            LivePill(online: store.errorMessage == nil && store.lastUpdated != nil)
        }
    }

    private var statusCard: some View {
        NeonPanel {
            HStack {
                VStack(alignment: .leading, spacing: 5) {
                    Label("Scanning West Yorkshire", systemImage: "dot.radiowaves.left.and.right")
                        .font(.subheadline.bold()).foregroundStyle(.white)
                    Text(store.errorMessage ?? "Real-time • Verified open • Duplicate filtered")
                        .font(.caption).foregroundStyle(store.errorMessage == nil ? .secondary : .orange)
                }
                Spacer()
                VStack(alignment: .trailing, spacing: 2) {
                    Text("\(store.openLeads.count)").font(.title.bold())
                    Text("ACTIVE").font(.caption2.bold()).foregroundStyle(Color.zkCyan)
                }
            }
        }
    }

    private var metrics: some View {
        HStack(spacing: 8) {
            metric("Verified", "\(store.verifiedToday)", "checkmark.shield.fill")
            metric("Hot", "\(store.hotCount)", "flame.fill")
            metric("Live", "\(store.openLeads.count)", "wave.3.right")
        }
    }

    private func metric(_ title: String, _ value: String, _ icon: String) -> some View {
        VStack(alignment: .leading, spacing: 7) {
            Image(systemName: icon).foregroundStyle(Color.zkCyan)
            Text(value).font(.title2.bold())
            Text(title).font(.caption2).foregroundStyle(.secondary)
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .padding(12)
        .background(Color.zkPanel.opacity(0.78), in: RoundedRectangle(cornerRadius: 16))
        .overlay(RoundedRectangle(cornerRadius: 16).stroke(Color.zkCyan.opacity(0.15)))
    }

    private var cityStrip: some View {
        ScrollView(.horizontal, showsIndicators: false) {
            HStack(spacing: 8) {
                ForEach(cities, id: \.self) { city in
                    Button(city) { store.selectedCity = city }
                        .buttonStyle(.plain)
                        .font(.caption.bold())
                        .foregroundStyle(store.selectedCity == city ? Color.zkInk : .white)
                        .padding(.horizontal, 13).padding(.vertical, 8)
                        .background(store.selectedCity == city ? Color.zkCyan : Color.white.opacity(0.04), in: Capsule())
                        .overlay(Capsule().stroke(Color.zkCyan.opacity(0.3)))
                }
            }
        }
    }

    private var freshLeads: some View {
        VStack(alignment: .leading, spacing: 10) {
            HStack {
                Label("Fresh verified leads", systemImage: "bolt.fill").font(.headline)
                Spacer()
                if store.isLoading { ProgressView().tint(.zkCyan) }
            }
            if store.filteredLeads.isEmpty {
                VStack(spacing: 10) {
                    Image(systemName: "dot.radiowaves.up.forward").font(.largeTitle).foregroundStyle(.zkCyan)
                    Text(store.errorMessage == nil ? "No verified open leads right now" : "Connect the live backend to start scanning")
                        .font(.subheadline.bold())
                    Text("The app never inserts demo jobs. Only records returned by your live service appear here.")
                        .font(.caption).foregroundStyle(.secondary).multilineTextAlignment(.center)
                }
                .frame(maxWidth: .infinity).padding(.vertical, 30)
            } else {
                ForEach(store.filteredLeads.prefix(6)) { LeadRow(lead: $0) }
            }
        }
    }

    private var background: some View {
        LinearGradient(colors: [Color.zkInk, Color.black, Color.zkInk], startPoint: .topLeading, endPoint: .bottomTrailing)
            .ignoresSafeArea()
    }
}
