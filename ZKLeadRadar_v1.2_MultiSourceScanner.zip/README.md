# ZK Lead Radar v1.2

SwiftUI iPhone lead-opportunity radar for West Yorkshire.

## New in v1.2
- Multi-source public-web scanner.
- Broad web + indexed public Facebook, Reddit, Nextdoor, Gumtree, Mumsnet, forums and recent web/news queries.
- Per-source success count in Settings.
- Freshness requires a real feed timestamp under 24 hours.
- Intent/trade/location filtering and duplicate suppression.
- Potential leads appear on the existing MapKit map.
- Verified Live remains reserved for genuinely confirmed leads.

Bundle ID remains `com.zk.leadradar` for in-place SideStore updates.
