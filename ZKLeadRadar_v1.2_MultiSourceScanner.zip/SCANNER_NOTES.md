# ZK Lead Radar v1.2 — Multi-source public scanner

The app now searches multiple public web surfaces rather than relying on Reddit's old anonymous JSON endpoint.

Sources queried through public search/RSS indexes:
- broad indexed public web
- public Facebook pages that search engines can see
- public Reddit pages that search engines can see
- public Nextdoor pages that search engines can see
- Gumtree public pages
- Mumsnet/public discussions
- local forums/community pages
- generic indexed public posts
- recent web/news RSS

Important limitations:
- private Facebook groups, private Nextdoor content, logged-in Bark/MyBuilder jobs, and other account-only content are not bypassed or scraped.
- a result must contain contractor-buying intent, a supported West Yorkshire place, a supported trade term, and a timestamp under 24 hours.
- results without a trustworthy feed timestamp are rejected instead of being falsely labelled fresh.
- discovered posts are Potential until independently verified.
