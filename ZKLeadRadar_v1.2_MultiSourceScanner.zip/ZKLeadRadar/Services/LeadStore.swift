import SwiftUI

@MainActor
final class LeadStore: ObservableObject {
    @Published private(set) var leads: [Lead] = []
    @Published private(set) var isLoading = false
    @Published private(set) var isScanning = false
    @Published private(set) var lastUpdated: Date?
    @Published private(set) var lastScan: Date?
    @Published private(set) var lastScanCount = 0
    @Published private(set) var scannerSourcesChecked = 0
    @Published private(set) var scannerSourcesSucceeded = 0
    @Published private(set) var scannerSourceNames: [String] = []
    @Published private(set) var serviceOnline = false
    @Published var errorMessage: String?
    @Published var selectedCity = "All Areas"

    private var refreshTask: Task<Void, Never>?
    private var backendLeads: [Lead] = []
    private var discoveredLeads: [Lead] = []

    var openLeads: [Lead] { leads.filter { $0.isVerifiedOpen } }
    var potentialLeads: [Lead] { leads.filter { $0.isPotential } }

    func filtered(_ list: [Lead]) -> [Lead] {
        let base = list.sorted { $0.createdAt > $1.createdAt }
        guard selectedCity != "All Areas" else { return base }
        return base.filter { $0.city.caseInsensitiveCompare(selectedCity) == .orderedSame }
    }

    var filteredLeads: [Lead] { filtered(openLeads) }
    var filteredPotentialLeads: [Lead] { filtered(potentialLeads) }
    var filteredMapLeads: [Lead] { filtered(leads.filter { $0.isFresh && !$0.sold && !$0.contractorAssigned && !$0.duplicate }) }

    var verifiedToday: Int {
        let calendar = Calendar.current
        return openLeads.filter { calendar.isDateInToday($0.createdAt) }.count
    }

    var newLeadCount: Int { leads.filter { Date().timeIntervalSince($0.createdAt) < 3_600 }.count }

    var scannerStatusText: String {
        if isScanning { return "Scanning public web sources…" }
        if let lastScan {
            let mins = max(0, Int(Date().timeIntervalSince(lastScan) / 60))
            let sourceText = scannerSourcesChecked > 0 ? " • \(scannerSourcesSucceeded)/\(scannerSourcesChecked) sources online" : ""
            return lastScanCount == 0
                ? "Scan complete • 0 fresh matches\(sourceText) • \(mins)m ago"
                : "Scan complete • \(lastScanCount) fresh match\(lastScanCount == 1 ? "" : "es")\(sourceText) • \(mins)m ago"
        }
        return "Scanner ready"
    }

    var statusText: String { scannerStatusText }

    func start() {
        guard refreshTask == nil else { return }
        refreshTask = Task { [weak self] in
            guard let self else { return }
            await self.refreshAll()
            while !Task.isCancelled {
                try? await Task.sleep(nanoseconds: 180_000_000_000)
                await self.refreshAll()
            }
        }
    }

    func stop() {
        refreshTask?.cancel()
        refreshTask = nil
    }

    func refreshAll() async {
        async let backend: Void = refreshBackend()
        async let scanner: Void = scanPublicSources()
        _ = await (backend, scanner)
    }

    func refresh() async { await refreshAll() }

    private func refreshBackend() async {
        if leads.isEmpty { isLoading = true }
        defer { isLoading = false }
        do {
            backendLeads = try await APIClient.shared.fetchLeads()
            lastUpdated = Date()
            serviceOnline = true
            errorMessage = nil
        } catch {
            serviceOnline = false
            // Public discovery can still work when the verification backend is offline.
            errorMessage = nil
        }
        mergeFeeds()
    }

    func scanPublicSources() async {
        guard !isScanning else { return }
        isScanning = true
        defer { isScanning = false }
        let result = await PublicLeadScanner.shared.scan()
        discoveredLeads = result.leads
        scannerSourcesChecked = result.sourcesChecked
        scannerSourcesSucceeded = result.sourcesSucceeded
        scannerSourceNames = result.sourceNames
        lastScanCount = discoveredLeads.count
        lastScan = Date()
        mergeFeeds()
    }

    private func mergeFeeds() {
        var merged: [String: Lead] = [:]
        for lead in discoveredLeads { merged[lead.id] = lead }
        for lead in backendLeads { merged[lead.id] = lead }
        leads = merged.values
            .filter { $0.isFresh && !$0.sold && !$0.contractorAssigned && !$0.duplicate }
            .sorted { $0.createdAt > $1.createdAt }
    }
}
