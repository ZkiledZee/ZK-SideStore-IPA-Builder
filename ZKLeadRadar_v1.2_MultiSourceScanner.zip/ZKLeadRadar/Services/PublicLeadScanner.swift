import Foundation
import CoreLocation

actor PublicLeadScanner {
    static let shared = PublicLeadScanner()

    struct ScanSummary: Sendable {
        let leads: [Lead]
        let sourcesChecked: Int
        let sourcesSucceeded: Int
        let sourceNames: [String]
    }

    fileprivate struct WebHit: Sendable {
        let sourceName: String
        let title: String
        let description: String
        let link: String
        let publishedAt: Date?
    }

    private struct SearchSource: Sendable {
        let name: String
        let query: String
        let endpoint: Endpoint

        enum Endpoint: Sendable {
            case bingRSS
            case googleNewsRSS
        }
    }

    private let cityCoordinates: [String: CLLocationCoordinate2D] = [
        "Bradford": .init(latitude: 53.7950, longitude: -1.7594),
        "Leeds": .init(latitude: 53.8008, longitude: -1.5491),
        "Huddersfield": .init(latitude: 53.6458, longitude: -1.7850),
        "Halifax": .init(latitude: 53.7250, longitude: -1.8630),
        "Wakefield": .init(latitude: 53.6833, longitude: -1.4977),
        "Keighley": .init(latitude: 53.8670, longitude: -1.9060),
        "Ilkley": .init(latitude: 53.9245, longitude: -1.8233),
        "Pudsey": .init(latitude: 53.7950, longitude: -1.6630),
        "Dewsbury": .init(latitude: 53.6900, longitude: -1.6290),
        "Batley": .init(latitude: 53.7160, longitude: -1.6350),
        "Morley": .init(latitude: 53.7440, longitude: -1.5980),
        "Shipley": .init(latitude: 53.8330, longitude: -1.7770),
        "Bingley": .init(latitude: 53.8480, longitude: -1.8380),
        "Cleckheaton": .init(latitude: 53.7240, longitude: -1.7120),
        "Brighouse": .init(latitude: 53.7020, longitude: -1.7800),
        "Ossett": .init(latitude: 53.6800, longitude: -1.5800),
        "Castleford": .init(latitude: 53.7250, longitude: -1.3550),
        "Pontefract": .init(latitude: 53.6910, longitude: -1.3120)
    ]

    private let intentTerms = [
        "need a", "need an", "looking for", "recommend a", "recommend me",
        "anyone know", "any recommendations", "can anyone recommend", "quote for",
        "need someone", "urgent", "asap", "who can", "tradesman", "contractor",
        "does anyone know", "after a", "seeking a", "looking to get", "need help with"
    ]

    private let tradeTerms: [(category: String, words: [String])] = [
        ("Roofing", ["roofer", "roofing", "roof repair", "leaking roof", "roof leak", "gutter", "guttering", "flat roof", "ridge tile"]),
        ("Plumbing", ["plumber", "plumbing", "pipe leak", "leaking pipe", "tap repair", "toilet repair", "burst pipe"]),
        ("Heating", ["boiler", "heating engineer", "central heating", "radiator", "gas engineer", "boiler repair", "boiler replacement"]),
        ("Drainage", ["blocked drain", "drainage", "drain unblock", "blocked toilet", "sewer", "drain cleaner"]),
        ("Electrical", ["electrician", "electrical", "rewire", "fuse box", "consumer unit", "socket", "lighting fault"]),
        ("Building", ["builder", "building work", "bricklayer", "brickwork", "extension", "renovation", "plasterer", "joiner", "carpenter"])
    ]

    private let advertSignals = [
        "we offer", "our services", "call us today", "free quotation", "fully insured",
        "years experience", "dm for quote", "available for work", "no job too small",
        "competitive prices", "local tradesman", "book now", "contact us for"
    ]

    func scan() async -> ScanSummary {
        let sources = buildSources()
        var allHits: [WebHit] = []
        var succeeded = 0
        var succeededNames: [String] = []

        await withTaskGroup(of: (String, [WebHit]?).self) { group in
            for source in sources {
                group.addTask { [source] in
                    do {
                        let hits = try await self.scan(source)
                        return (source.name, hits)
                    } catch {
                        return (source.name, nil)
                    }
                }
            }

            for await (name, hits) in group {
                if let hits {
                    succeeded += 1
                    succeededNames.append(name)
                    allHits.append(contentsOf: hits)
                }
            }
        }

        let leads = deduplicate(allHits.compactMap(makeLead(from:)))
            .sorted { $0.createdAt > $1.createdAt }

        return ScanSummary(
            leads: leads,
            sourcesChecked: sources.count,
            sourcesSucceeded: succeeded,
            sourceNames: succeededNames.sorted()
        )
    }

    private func buildSources() -> [SearchSource] {
        let locations = "(Bradford OR Leeds OR Huddersfield OR Halifax OR Wakefield OR Keighley OR Ilkley OR Pudsey OR Dewsbury OR Batley OR Morley)"
        let trades = "(roofer OR roofing OR plumber OR boiler OR \"heating engineer\" OR \"blocked drain\" OR electrician OR builder OR plasterer OR joiner)"
        let intent = "(\"need a\" OR \"looking for\" OR \"can anyone recommend\" OR \"need someone\" OR \"quote for\" OR urgent)"
        let broad = "\(intent) \(trades) \(locations)"

        return [
            .init(name: "Broad public web", query: broad, endpoint: .bingRSS),
            .init(name: "Public Facebook pages", query: "site:facebook.com \(broad)", endpoint: .bingRSS),
            .init(name: "Public Reddit pages", query: "site:reddit.com \(broad)", endpoint: .bingRSS),
            .init(name: "Public Nextdoor pages", query: "site:nextdoor.co.uk \(broad)", endpoint: .bingRSS),
            .init(name: "Gumtree public pages", query: "site:gumtree.com \(broad)", endpoint: .bingRSS),
            .init(name: "Mumsnet public discussions", query: "site:mumsnet.com \(broad)", endpoint: .bingRSS),
            .init(name: "Local forum pages", query: "(forum OR community OR discussion) \(broad)", endpoint: .bingRSS),
            .init(name: "Indexed public posts", query: "(post OR posted OR recommendation) \(broad)", endpoint: .bingRSS),
            .init(name: "Recent web/news mentions", query: "\(trades) \(locations) \"looking for\"", endpoint: .googleNewsRSS)
        ]
    }

    private func scan(_ source: SearchSource) async throws -> [WebHit] {
        let url: URL
        switch source.endpoint {
        case .bingRSS:
            var components = URLComponents(string: "https://www.bing.com/search")!
            components.queryItems = [
                .init(name: "q", value: source.query),
                .init(name: "format", value: "rss"),
                .init(name: "cc", value: "gb"),
                .init(name: "setlang", value: "en-gb")
            ]
            guard let built = components.url else { return [] }
            url = built
        case .googleNewsRSS:
            var components = URLComponents(string: "https://news.google.com/rss/search")!
            components.queryItems = [
                .init(name: "q", value: source.query),
                .init(name: "hl", value: "en-GB"),
                .init(name: "gl", value: "GB"),
                .init(name: "ceid", value: "GB:en")
            ]
            guard let built = components.url else { return [] }
            url = built
        }

        var request = URLRequest(url: url)
        request.timeoutInterval = 8
        request.cachePolicy = .reloadIgnoringLocalCacheData
        request.setValue("Mozilla/5.0 (iPhone; CPU iPhone OS 18_0 like Mac OS X) AppleWebKit/605.1.15 ZKLeadRadar/1.2", forHTTPHeaderField: "User-Agent")
        request.setValue("application/rss+xml, application/xml, text/xml, */*", forHTTPHeaderField: "Accept")

        let (data, response) = try await URLSession.shared.data(for: request)
        guard let http = response as? HTTPURLResponse, (200..<300).contains(http.statusCode) else {
            throw URLError(.badServerResponse)
        }

        return RSSParser.parse(data: data, sourceName: source.name)
    }

    private func makeLead(from hit: WebHit) -> Lead? {
        let body = "\(hit.title) \(hit.description)".replacingOccurrences(of: "<[^>]+>", with: " ", options: .regularExpression)
        let lower = body.lowercased()

        guard hasIntent(lower), let city = detectedCity(lower), let trade = detectedTrade(lower) else { return nil }
        guard !looksLikeAdvert(lower) else { return nil }

        // We only accept results whose RSS feed provides a recent timestamp. A search result with
        // no date is not allowed to masquerade as a fresh lead.
        guard let published = hit.publishedAt else { return nil }
        let age = Date().timeIntervalSince(published)
        guard age >= -300, age < 86_400 else { return nil }

        let coordinate = cityCoordinates[city] ?? cityCoordinates["Leeds"]!
        let cleanTitle = stripHTML(hit.title).trimmingCharacters(in: .whitespacesAndNewlines)
        let cleanDescription = stripHTML(hit.description).trimmingCharacters(in: .whitespacesAndNewlines)
        guard !cleanTitle.isEmpty else { return nil }

        let canonical = canonicalURL(hit.link)
        let stable = stableID("\(canonical)|\(cleanTitle)")

        return Lead(
            id: "web_\(stable)",
            title: String(cleanTitle.prefix(180)),
            category: trade,
            city: city,
            postcode: nil,
            latitude: coordinate.latitude,
            longitude: coordinate.longitude,
            createdAt: published,
            estimatedMin: nil,
            estimatedMax: nil,
            contactName: nil,
            phone: nil,
            email: nil,
            source: hit.sourceName,
            sourceURL: canonical,
            excerpt: cleanDescription.isEmpty ? nil : String(cleanDescription.prefix(260)),
            locationApproximate: true,
            discoveryScore: discoveryScore(lower),
            phoneVerified: false,
            customerConfirmedOpen: false,
            contractorAssigned: false,
            duplicate: false,
            sold: false,
            contactVerified: false,
            openConfirmedAt: nil,
            verification: "public-discovery"
        )
    }

    private func hasIntent(_ text: String) -> Bool {
        intentTerms.contains { text.contains($0) }
    }

    private func detectedCity(_ text: String) -> String? {
        cityCoordinates.keys.sorted { $0.count > $1.count }.first { text.contains($0.lowercased()) }
    }

    private func detectedTrade(_ text: String) -> String? {
        tradeTerms.first { group in group.words.contains { text.contains($0) } }?.category
    }

    private func looksLikeAdvert(_ text: String) -> Bool {
        advertSignals.contains { text.contains($0) }
    }

    private func discoveryScore(_ text: String) -> Int {
        var score = 45
        if text.contains("urgent") || text.contains("asap") { score += 15 }
        if text.contains("need a") || text.contains("need someone") || text.contains("need an") { score += 15 }
        if text.contains("looking for") || text.contains("can anyone recommend") { score += 10 }
        if text.contains("quote") { score += 5 }
        if text.contains("today") || text.contains("this week") { score += 5 }
        return min(score, 95)
    }

    private func deduplicate(_ leads: [Lead]) -> [Lead] {
        var seenIDs = Set<String>()
        var seenFingerprints = Set<String>()
        return leads.filter { lead in
            let title = lead.title.lowercased().filter { $0.isLetter || $0.isNumber }
            let fingerprint = "\(lead.city.lowercased())|\(lead.category.lowercased())|\(String(title.prefix(90)))"
            guard !seenIDs.contains(lead.id), !seenFingerprints.contains(fingerprint) else { return false }
            seenIDs.insert(lead.id)
            seenFingerprints.insert(fingerprint)
            return true
        }
    }

    private func stripHTML(_ text: String) -> String {
        let stripped = text.replacingOccurrences(of: "<[^>]+>", with: " ", options: .regularExpression)
        return stripped
            .replacingOccurrences(of: "&amp;", with: "&")
            .replacingOccurrences(of: "&quot;", with: "\"")
            .replacingOccurrences(of: "&#39;", with: "'")
            .replacingOccurrences(of: "&lt;", with: "<")
            .replacingOccurrences(of: "&gt;", with: ">")
            .replacingOccurrences(of: "\\s+", with: " ", options: .regularExpression)
    }

    private func canonicalURL(_ raw: String) -> String {
        guard var components = URLComponents(string: raw) else { return raw }
        components.fragment = nil
        components.queryItems = components.queryItems?.filter { item in
            let name = item.name.lowercased()
            return !name.hasPrefix("utm_") && name != "gclid" && name != "fbclid"
        }
        return components.string ?? raw
    }

    private func stableID(_ input: String) -> String {
        var hash: UInt64 = 1469598103934665603
        for byte in input.utf8 {
            hash ^= UInt64(byte)
            hash = hash &* 1099511628211
        }
        return String(hash, radix: 16)
    }
}

private final class RSSParser: NSObject, XMLParserDelegate {
    private let sourceName: String
    private var hits: [PublicLeadScanner.WebHit] = []
    private var currentElement = ""
    private var title = ""
    private var link = ""
    private var desc = ""
    private var pubDate = ""
    private var insideItem = false

    init(sourceName: String) {
        self.sourceName = sourceName
    }

    static func parse(data: Data, sourceName: String) -> [PublicLeadScanner.WebHit] {
        let delegate = RSSParser(sourceName: sourceName)
        let parser = XMLParser(data: data)
        parser.delegate = delegate
        parser.shouldResolveExternalEntities = false
        _ = parser.parse()
        return delegate.hits
    }

    func parser(_ parser: XMLParser, didStartElement elementName: String, namespaceURI: String?, qualifiedName qName: String?, attributes attributeDict: [String : String] = [:]) {
        currentElement = elementName.lowercased()
        if currentElement == "item" || currentElement == "entry" {
            insideItem = true
            title = ""
            link = ""
            desc = ""
            pubDate = ""
        }
        if insideItem, currentElement == "link", let href = attributeDict["href"], !href.isEmpty {
            link = href
        }
    }

    func parser(_ parser: XMLParser, foundCharacters string: String) {
        guard insideItem else { return }
        switch currentElement {
        case "title": title += string
        case "link": if link.isEmpty { link += string }
        case "description", "summary", "content": desc += string
        case "pubdate", "published", "updated": pubDate += string
        default: break
        }
    }

    func parser(_ parser: XMLParser, didEndElement elementName: String, namespaceURI: String?, qualifiedName qName: String?) {
        let ended = elementName.lowercased()
        if ended == "item" || ended == "entry" {
            insideItem = false
            if !title.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty,
               !link.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty {
                hits.append(.init(
                    sourceName: sourceName,
                    title: title,
                    description: desc,
                    link: link.trimmingCharacters(in: .whitespacesAndNewlines),
                    publishedAt: Self.parseDate(pubDate)
                ))
            }
        }
        currentElement = ""
    }

    private static func parseDate(_ raw: String) -> Date? {
        let value = raw.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !value.isEmpty else { return nil }

        let formats = [
            "EEE, dd MMM yyyy HH:mm:ss Z",
            "EEE, d MMM yyyy HH:mm:ss Z",
            "yyyy-MM-dd'T'HH:mm:ssZ",
            "yyyy-MM-dd'T'HH:mm:ss.SSSZ",
            "yyyy-MM-dd'T'HH:mm:ssXXXXX",
            "yyyy-MM-dd'T'HH:mm:ss.SSSXXXXX"
        ]
        let formatter = DateFormatter()
        formatter.locale = Locale(identifier: "en_US_POSIX")
        for format in formats {
            formatter.dateFormat = format
            if let date = formatter.date(from: value) { return date }
        }
        return ISO8601DateFormatter().date(from: value)
    }
}
