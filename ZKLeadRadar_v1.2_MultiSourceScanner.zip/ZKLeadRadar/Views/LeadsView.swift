import SwiftUI

struct LeadsView: View {
    @EnvironmentObject var store: LeadStore
    @State private var mode = 0

    var body: some View {
        NavigationStack {
            VStack(spacing: 10) {
                Picker("Lead status", selection: $mode) {
                    Text("Verified Live").tag(0)
                    Text("Potential").tag(1)
                }
                .pickerStyle(.segmented)
                .padding(.horizontal, 14)
                .padding(.top, 8)

                List(currentLeads) { lead in
                    LeadRow(lead: lead)
                        .listRowBackground(Color.clear)
                        .listRowSeparator(.hidden)
                }
                .listStyle(.plain)
                .scrollContentBackground(.hidden)
                .background(Color.zkInk)
                .overlay { emptyState }
            }
            .background(Color.zkInk)
            .navigationTitle("Leads")
            .toolbar {
                Button { Task { await store.scanPublicSources() } } label: { Image(systemName: "scope") }
            }
        }
    }

    private var currentLeads: [Lead] {
        mode == 0 ? store.filteredLeads : store.filteredPotentialLeads
    }

    @ViewBuilder
    private var emptyState: some View {
        if currentLeads.isEmpty {
            ContentUnavailableView(
                mode == 0 ? "No verified live leads" : "No potential leads",
                systemImage: mode == 0 ? "checkmark.shield" : "hourglass",
                description: Text(mode == 0
                    ? "Only fresh customer-confirmed jobs that pass verification appear here."
                    : "Fresh discovered or submitted jobs waiting for customer verification appear here.")
            )
        }
    }
}
