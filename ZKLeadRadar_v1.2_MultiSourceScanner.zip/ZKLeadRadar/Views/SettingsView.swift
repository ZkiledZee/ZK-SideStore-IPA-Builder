import SwiftUI

struct SettingsView: View {
    @EnvironmentObject var store: LeadStore

    var body: some View {
        NavigationStack {
            Form {
                Section("Public scanner") {
                    LabeledContent("Status", value: store.isScanning ? "Scanning" : "Ready")
                    Text(store.scannerStatusText)
                        .foregroundStyle(store.isScanning ? Color.zkCyan : Color.secondary)
                    if let date = store.lastScan {
                        LabeledContent("Last scan", value: date.formatted(date: .omitted, time: .standard))
                    }
                    LabeledContent("Fresh matches", value: "\(store.lastScanCount)")
                    if store.scannerSourcesChecked > 0 {
                        LabeledContent("Sources online", value: "\(store.scannerSourcesSucceeded)/\(store.scannerSourcesChecked)")
                    }
                    Button(store.isScanning ? "Scanning…" : "Scan now") {
                        Task { await store.scanPublicSources() }
                    }
                    .disabled(store.isScanning)
                }

                Section("Sources") {
                    Label("Broad indexed public web", systemImage: "globe")
                    Label("Public Facebook pages", systemImage: "person.2")
                    Label("Public Reddit pages", systemImage: "bubble.left.and.bubble.right")
                    Label("Public Nextdoor pages", systemImage: "house")
                    Label("Gumtree public pages", systemImage: "list.bullet.rectangle")
                    Label("Mumsnet/public discussions", systemImage: "text.bubble")
                    Label("Local forums & community pages", systemImage: "person.3")
                    Label("Recent indexed web/news", systemImage: "newspaper")
                    Text("The scanner uses public web indexes so it can discover posts across many sites without bypassing logins. Private groups and account-only marketplaces require authorised access and are not secretly scraped.")
                        .font(.footnote)
                        .foregroundStyle(.secondary)
                }

                Section("Verification backend") {
                    LabeledContent("Status", value: store.serviceOnline ? "Connected" : "Offline")
                    Text("The scanner works independently. This backend is only needed to turn a Potential lead into Verified Live.")
                        .font(.footnote)
                        .foregroundStyle(.secondary)
                    if let date = store.lastUpdated {
                        LabeledContent("Last sync", value: date.formatted(date: .omitted, time: .standard))
                    }
                }

                Section("Verification rules") {
                    Label("Fresh: under 24 hours", systemImage: "clock.badge.checkmark")
                    Label("Customer confirms job is still open", systemImage: "person.crop.circle.badge.checkmark")
                    Label("No contractor assigned", systemImage: "xmark.circle")
                    Label("Duplicate filtered", systemImage: "square.on.square.dashed")
                    Label("Sold leads hidden", systemImage: "lock.fill")
                }

                Section("Important") {
                    Text("Publicly discovered posts are Potential leads only. Verified Live is only shown after a genuine verification step; the app never guesses that status.")
                }
            }
            .scrollContentBackground(.hidden)
            .background(Color.zkInk)
            .navigationTitle("Settings")
        }
    }
}
