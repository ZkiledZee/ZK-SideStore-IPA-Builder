import SwiftUI

struct HomeView: View {
    @EnvironmentObject var store: LeadStore
    @Binding var selectedTab: Int

    private let cities = ["All Areas", "Bradford", "Leeds", "Huddersfield", "Halifax", "Wakefield"]

    var body: some View {
        ScrollView(showsIndicators: false) {
            VStack(spacing: 12) {
                header
                scannerCard
                metrics
                cityStrip
                freshLeads
                potentialQueue
            }
            .padding(.horizontal, 15)
            .padding(.top, 8)
            .padding(.bottom, 112)
        }
        .background(background)
        .refreshable { await store.refresh() }
        .task { store.start() }
        .onDisappear { store.stop() }
    }

    private var header: some View {
        HStack(spacing: 11) {
            ZKMark()
            Text("ZK Lead Radar")
                .font(.system(size: 25, weight: .bold, design: .rounded))
                .foregroundStyle(.white)
            Spacer()
            LivePill(online: !store.isScanning && store.lastScan != nil)
        }
        .padding(.top, 2)
    }

    private var scannerCard: some View {
        VStack(spacing: 9) {
            HStack(alignment: .top) {
                VStack(alignment: .leading, spacing: 5) {
                    Label("Scanning West Yorkshire", systemImage: "dot.radiowaves.left.and.right")
                        .font(.system(size: 14, weight: .semibold))
                        .foregroundStyle(.white)
                    Text(store.statusText)
                        .font(.system(size: 11, weight: .medium))
                        .foregroundStyle(store.serviceOnline ? Color.white.opacity(0.62) : Color.white.opacity(0.48))
                        .lineLimit(2)
                }

                Spacer()

                VStack(alignment: .leading, spacing: 1) {
                    Text("Active Now")
                        .font(.system(size: 10))
                        .foregroundStyle(Color.white.opacity(0.60))
                    HStack(spacing: 8) {
                        Text("\(store.openLeads.count)")
                            .font(.system(size: 25, weight: .bold, design: .rounded))
                        Image(systemName: "chart.line.uptrend.xyaxis")
                            .foregroundStyle(Color.zkCyan)
                    }
                }
                .padding(.horizontal, 12)
                .padding(.vertical, 9)
                .background(Color.zkPanel.opacity(0.92), in: RoundedRectangle(cornerRadius: 14))
                .overlay(RoundedRectangle(cornerRadius: 14).stroke(Color.zkCyan.opacity(0.16)))
            }
            .padding(.horizontal, 12)
            .padding(.top, 10)

            RadarMapView(leads: store.filteredMapLeads)
                .frame(height: 315)
                .padding(.horizontal, 8)
                .padding(.bottom, 8)
        }
        .background(Color.zkPanel.opacity(0.72), in: RoundedRectangle(cornerRadius: 18, style: .continuous))
        .overlay(RoundedRectangle(cornerRadius: 18, style: .continuous).stroke(Color.zkCyan.opacity(0.18), lineWidth: 1))
    }

    private var metrics: some View {
        HStack(spacing: 7) {
            metric(title: "Verified Today", value: "\(store.verifiedToday)", icon: "checkmark.shield.fill", delta: nil)
            metric(title: "Potential", value: "\(store.potentialLeads.count)", icon: "hourglass.circle.fill", delta: nil)
            metric(title: "Buyers Active", value: "—", icon: "person.2.fill", delta: nil)
            metric(title: "Response Rate", value: "—", icon: "chart.line.uptrend.xyaxis", delta: nil)
        }
    }

    private func metric(title: String, value: String, icon: String, delta: String?) -> some View {
        VStack(alignment: .leading, spacing: 5) {
            Image(systemName: icon)
                .font(.system(size: 17, weight: .semibold))
                .foregroundStyle(Color.zkCyan)
                .frame(height: 20)
            Text(title)
                .font(.system(size: 9, weight: .medium))
                .foregroundStyle(Color.white.opacity(0.72))
                .lineLimit(1)
                .minimumScaleFactor(0.7)
            Text(value)
                .font(.system(size: 23, weight: .bold, design: .rounded))
                .foregroundStyle(.white)
            if let delta {
                Text(delta)
                    .font(.system(size: 9, weight: .semibold))
                    .foregroundStyle(Color.zkCyan)
            } else {
                Text("LIVE")
                    .font(.system(size: 8, weight: .bold))
                    .foregroundStyle(Color.zkCyan.opacity(0.8))
            }
        }
        .frame(maxWidth: .infinity, minHeight: 104, alignment: .leading)
        .padding(.horizontal, 9)
        .padding(.vertical, 10)
        .background(Color.zkPanel.opacity(0.82), in: RoundedRectangle(cornerRadius: 14))
        .overlay(RoundedRectangle(cornerRadius: 14).stroke(Color.zkCyan.opacity(0.16), lineWidth: 1))
    }

    private var cityStrip: some View {
        ScrollView(.horizontal, showsIndicators: false) {
            HStack(spacing: 8) {
                ForEach(cities, id: \.self) { city in
                    Button {
                        store.selectedCity = city
                    } label: {
                        HStack(spacing: 5) {
                            if city == "All Areas" {
                                Image(systemName: "scope")
                                    .font(.system(size: 10, weight: .bold))
                            }
                            Text(city)
                                .font(.system(size: 11, weight: .semibold))
                        }
                        .foregroundStyle(store.selectedCity == city ? Color.zkCyan : Color.white.opacity(0.76))
                        .padding(.horizontal, 12)
                        .padding(.vertical, 8)
                        .background(
                            store.selectedCity == city ? Color.zkCyan.opacity(0.11) : Color.white.opacity(0.025),
                            in: Capsule()
                        )
                        .overlay(
                            Capsule().stroke(
                                store.selectedCity == city ? Color.zkCyan.opacity(0.70) : Color.zkCyan.opacity(0.18),
                                lineWidth: 1
                            )
                        )
                        .shadow(color: store.selectedCity == city ? Color.zkCyan.opacity(0.3) : Color.clear, radius: 6)
                    }
                    .buttonStyle(.plain)
                }
            }
        }
    }

    private var freshLeads: some View {
        VStack(alignment: .leading, spacing: 9) {
            HStack {
                Label("Fresh Verified Leads", systemImage: "bolt.fill")
                    .font(.system(size: 17, weight: .bold))
                    .foregroundStyle(.white)
                Spacer()
                Button("View all") { selectedTab = 1 }
                    .buttonStyle(.plain)
                    .font(.system(size: 11, weight: .medium))
                    .foregroundStyle(Color.white.opacity(0.68))
            }

            if store.isLoading && store.leads.isEmpty {
                HStack {
                    Spacer()
                    ProgressView().tint(Color.zkCyan)
                    Spacer()
                }
                .padding(.vertical, 24)
            } else if store.filteredLeads.isEmpty {
                VStack(spacing: 8) {
                    Image(systemName: "scope")
                        .font(.system(size: 29, weight: .light))
                        .foregroundStyle(Color.zkCyan)
                    Text("No verified open leads right now")
                        .font(.system(size: 14, weight: .semibold))
                    Text("Only genuine backend leads that pass freshness, phone verification, open-job confirmation, duplicate and assignment checks will appear here.")
                        .font(.system(size: 11))
                        .foregroundStyle(Color.white.opacity(0.58))
                        .multilineTextAlignment(.center)
                }
                .frame(maxWidth: .infinity)
                .padding(.vertical, 22)
                .padding(.horizontal, 16)
                .background(Color.zkPanel.opacity(0.60), in: RoundedRectangle(cornerRadius: 15))
                .overlay(RoundedRectangle(cornerRadius: 15).stroke(Color.zkCyan.opacity(0.12)))
            } else {
                ForEach(store.filteredLeads.prefix(4)) { lead in
                    LeadRow(lead: lead)
                }
            }
        }
    }

    private var potentialQueue: some View {
        VStack(alignment: .leading, spacing: 9) {
            HStack {
                Label("Potential Leads", systemImage: "hourglass.circle.fill")
                    .font(.system(size: 17, weight: .bold))
                    .foregroundStyle(.white)
                Spacer()
                Text("Public discoveries")
                    .font(.system(size: 10, weight: .medium))
                    .foregroundStyle(Color.orange.opacity(0.9))
            }

            if store.filteredPotentialLeads.isEmpty {
                Text("No fresh public contractor requests found in the latest scan.")
                    .font(.system(size: 11))
                    .foregroundStyle(Color.white.opacity(0.52))
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .padding(14)
                    .background(Color.zkPanel.opacity(0.50), in: RoundedRectangle(cornerRadius: 14))
            } else {
                ForEach(store.filteredPotentialLeads.prefix(3)) { lead in
                    LeadRow(lead: lead)
                }
            }
        }
    }

    private var background: some View {
        LinearGradient(
            colors: [Color.zkInk, Color.black, Color.zkInk],
            startPoint: .topLeading,
            endPoint: .bottomTrailing
        )
        .ignoresSafeArea()
    }
}
