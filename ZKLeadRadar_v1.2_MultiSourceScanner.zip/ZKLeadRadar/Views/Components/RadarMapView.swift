import SwiftUI
import MapKit

struct RadarMapView: View {
    let leads: [Lead]

    @State private var position: MapCameraPosition = .region(
        MKCoordinateRegion(
            center: CLLocationCoordinate2D(latitude: 53.77, longitude: -1.69),
            span: MKCoordinateSpan(latitudeDelta: 0.58, longitudeDelta: 0.72)
        )
    )

    var body: some View {
        ZStack {
            Map(position: $position, interactionModes: [.pan, .zoom]) {
                ForEach(leads) { lead in
                    Annotation(lead.title, coordinate: lead.coordinate) {
                        VStack(spacing: 3) {
                            ZStack {
                                Circle()
                                    .fill((lead.isVerifiedOpen ? Color.zkCyan : Color.orange).opacity(0.22))
                                    .frame(width: 30, height: 30)
                                Circle()
                                    .stroke(lead.isVerifiedOpen ? Color.zkCyan : Color.orange, lineWidth: 2)
                                    .frame(width: 20, height: 20)
                                Image(systemName: lead.isVerifiedOpen ? "checkmark" : "hammer.fill")
                                    .font(.system(size: 8, weight: .bold))
                                    .foregroundStyle(.white)
                            }
                            .shadow(color: (lead.isVerifiedOpen ? Color.zkCyan : Color.orange).opacity(0.8), radius: 8)

                            Text(lead.city)
                                .font(.system(size: 9, weight: .semibold))
                                .foregroundStyle(.white)
                                .padding(.horizontal, 5)
                                .padding(.vertical, 2)
                                .background(Color.black.opacity(0.72), in: Capsule())
                        }
                    }
                }
            }
            .mapStyle(.standard(elevation: .flat, pointsOfInterest: .excludingAll, showsTraffic: false))
            .saturation(0.15)
            .contrast(1.18)
            .colorMultiply(Color(red: 0.22, green: 0.66, blue: 0.82))
        }
        .clipShape(RoundedRectangle(cornerRadius: 18, style: .continuous))
        .overlay(
            RoundedRectangle(cornerRadius: 18, style: .continuous)
                .stroke(Color.zkCyan.opacity(0.28), lineWidth: 1)
        )
    }
}
