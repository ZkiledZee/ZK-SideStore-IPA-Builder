import Foundation
import CoreLocation

actor PublicLeadScanner {
    static let shared = PublicLeadScanner()

    struct RedditListing: Decodable {
        let data: ListingData
        struct ListingData: Decodable { let children: [Child] }
        struct Child: Decodable { let data: Post }
        struct Post: Decodable {
            let id: String
            let title: String
            let selftext: String?
            let created_utc: Double
            let permalink: String
            let subreddit: String?
        }
    }

    private let cityCoordinates: [String: CLLocationCoordinate2D] = [
        "Bradford": .init(latitude: 53.7950, longitude: -1.7594),
        "Leeds": .init(latitude: 53.8008, longitude: -1.5491),
        "Huddersfield": .init(latitude: 53.6458, longitude: -1.7850),
        "Halifax": .init(latitude: 53.7250, longitude: -1.8630),
        "Wakefield": .init(latitude: 53.6833, longitude: -1.4977),
        "Keighley": .init(latitude: 53.8670, longitude: -1.9060),
        "Ilkley": .init(latitude: 53.9245, longitude: -1.8233),
        "Pudsey": .init(latitude: 53.7950, longitude: -1.6630),
        "Dewsbury": .init(latitude: 53.6900, longitude: -1.6290),
        "Batley": .init(latitude: 53.7160, longitude: -1.6350),
        "Morley": .init(latitude: 53.7440, longitude: -1.5980)
    ]

    private let intentTerms = [
        "need a", "need an", "looking for", "recommend a", "recommend me",
        "anyone know", "any recommendations", "can anyone recommend", "quote for",
        "need someone", "urgent", "who can", "tradesman", "contractor"
    ]

    private let tradeTerms: [(category: String, words: [String])] = [
        ("Roofing", ["roofer", "roofing", "roof repair", "leaking roof", "roof leak", "gutter", "guttering"]),
        ("Plumbing", ["plumber", "plumbing", "pipe leak", "leaking pipe", "tap repair", "toilet repair"]),
        ("Heating", ["boiler", "heating engineer", "central heating", "radiator", "gas engineer"]),
        ("Drainage", ["blocked drain", "drainage", "drain unblock", "blocked toilet", "sewer"]),
        ("Electrical", ["electrician", "electrical", "rewire", "fuse box", "consumer unit"]),
        ("Building", ["builder", "building work", "bricklayer", "brickwork", "extension", "renovation"])
    ]

    func scan() async -> [Lead] {
        var results: [Lead] = []
        // Public Reddit search is one discovery adapter. If Reddit refuses anonymous access,
        // the scanner fails closed and the rest of the app continues normally.
        if let reddit = try? await scanReddit() {
            results.append(contentsOf: reddit)
        }
        return deduplicate(results).sorted { $0.createdAt > $1.createdAt }
    }

    private func scanReddit() async throws -> [Lead] {
        let query = "(roofer OR roofing OR plumber OR boiler OR \"heating engineer\" OR \"blocked drain\" OR electrician OR builder) (Bradford OR Leeds OR Huddersfield OR Halifax OR Wakefield OR Keighley OR Ilkley OR Pudsey OR Dewsbury OR Batley OR Morley)"
        var components = URLComponents(string: "https://www.reddit.com/search.json")!
        components.queryItems = [
            .init(name: "q", value: query),
            .init(name: "sort", value: "new"),
            .init(name: "t", value: "day"),
            .init(name: "limit", value: "100"),
            .init(name: "raw_json", value: "1")
        ]
        guard let url = components.url else { return [] }
        var request = URLRequest(url: url)
        request.timeoutInterval = 12
        request.setValue("ZKLeadRadar/1.1 public-opportunity-scanner", forHTTPHeaderField: "User-Agent")
        request.setValue("application/json", forHTTPHeaderField: "Accept")

        let (data, response) = try await URLSession.shared.data(for: request)
        guard let http = response as? HTTPURLResponse, (200..<300).contains(http.statusCode) else { return [] }
        let listing = try JSONDecoder().decode(RedditListing.self, from: data)
        let now = Date()

        return listing.data.children.compactMap { child in
            let post = child.data
            let created = Date(timeIntervalSince1970: post.created_utc)
            guard now.timeIntervalSince(created) >= 0, now.timeIntervalSince(created) < 86_400 else { return nil }
            let body = [post.title, post.selftext ?? ""].joined(separator: " ")
            let lower = body.lowercased()
            guard hasIntent(lower), let city = detectedCity(lower), let trade = detectedTrade(lower) else { return nil }
            guard !looksLikeAdvert(lower) else { return nil }
            let coordinate = cityCoordinates[city] ?? cityCoordinates["Leeds"]!
            let cleanTitle = post.title.trimmingCharacters(in: .whitespacesAndNewlines)
            let excerpt = String((post.selftext ?? "").trimmingCharacters(in: .whitespacesAndNewlines).prefix(240))

            return Lead(
                id: "reddit_\(post.id)",
                title: cleanTitle,
                category: trade,
                city: city,
                postcode: nil,
                latitude: coordinate.latitude,
                longitude: coordinate.longitude,
                createdAt: created,
                estimatedMin: nil,
                estimatedMax: nil,
                contactName: nil,
                phone: nil,
                email: nil,
                source: "Reddit / r/\(post.subreddit ?? "unknown")",
                sourceURL: "https://www.reddit.com\(post.permalink)",
                excerpt: excerpt.isEmpty ? nil : excerpt,
                locationApproximate: true,
                discoveryScore: discoveryScore(lower),
                phoneVerified: false,
                customerConfirmedOpen: false,
                contractorAssigned: false,
                duplicate: false,
                sold: false,
                contactVerified: false,
                openConfirmedAt: nil,
                verification: "public-discovery"
            )
        }
    }

    private func hasIntent(_ text: String) -> Bool {
        intentTerms.contains { text.contains($0) }
    }

    private func detectedCity(_ text: String) -> String? {
        cityCoordinates.keys.sorted { $0.count > $1.count }.first { text.contains($0.lowercased()) }
    }

    private func detectedTrade(_ text: String) -> String? {
        tradeTerms.first { group in group.words.contains { text.contains($0) } }?.category
    }

    private func looksLikeAdvert(_ text: String) -> Bool {
        let adSignals = ["we offer", "our services", "call us today", "free quotation", "fully insured", "years experience", "dm for quote", "available for work"]
        return adSignals.contains { text.contains($0) }
    }

    private func discoveryScore(_ text: String) -> Int {
        var score = 45
        if text.contains("urgent") || text.contains("asap") { score += 15 }
        if text.contains("need a") || text.contains("need someone") { score += 15 }
        if text.contains("looking for") || text.contains("can anyone recommend") { score += 10 }
        if text.contains("quote") { score += 5 }
        return min(score, 90)
    }

    private func deduplicate(_ leads: [Lead]) -> [Lead] {
        var seen = Set<String>()
        return leads.filter { lead in
            let normalized = "\(lead.city)|\(lead.category)|\(lead.title.lowercased().filter { $0.isLetter || $0.isNumber })"
            guard !seen.contains(normalized) else { return false }
            seen.insert(normalized)
            return true
        }
    }
}
