# ZK Lead Radar 1.1 — Public Opportunity Scanner

This build adds an on-device discovery scanner. It currently includes a public Reddit discovery adapter and is structured so more permitted public feeds/APIs can be added without changing the Lead model.

Rules:
- only posts less than 24h old
- must contain a West Yorkshire target location
- must contain a supported trade/service keyword
- must contain active buying-intent language (need / looking for / recommend / quote / urgent etc.)
- obvious contractor adverts are rejected
- duplicates are removed
- discoveries are Potential, never Verified Live
- map uses approximate city coordinates when a public post does not contain a precise address
- Verified Live still requires the verification backend/customer confirmation

Important: private/logged-in platforms are not scraped or bypassed. Add official APIs/authorized feeds for those sources.
