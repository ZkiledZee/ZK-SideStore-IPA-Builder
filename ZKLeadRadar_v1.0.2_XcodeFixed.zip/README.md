# ZK Lead Radar — one-repo build

This repo contains **everything** for the first live ZK Lead Radar build:

- SwiftUI iPhone app
- Apple MapKit live map + neon radar UI
- GitHub Actions unsigned IPA builder
- Netlify customer lead form
- Netlify Functions live API
- Netlify Blobs persistent lead storage

There is **no Supabase setup, SQL migration, API key or separate backend repo**.

## First-time setup

### 1) GitHub
Create a new empty GitHub repository and upload the **contents of this folder** to the repo root.

You should see these items at the top level:

- `.github/`
- `netlify/`
- `web/`
- `ZKLeadRadar/`
- `netlify.toml`
- `package.json`
- `project.yml`

GitHub Actions will automatically run `Build ZK Lead Radar IPA`.

### 2) Netlify — once only
In Netlify choose **Add new project → Import an existing project → GitHub**, then select the same repo.

Netlify reads `netlify.toml` automatically. Do not add a database and do not add environment variables.

If Netlify lets you choose the site name, use:

`zk-lead-radar`

The app is already configured for:

`https://zk-lead-radar.netlify.app/.netlify/functions`

If that Netlify name is unavailable and Netlify gives you a different URL, open:

`ZKLeadRadar/Info.plist`

and replace the value of `LIVE_API_BASE_URL` with:

`https://YOUR-ACTUAL-NETLIFY-SITE.netlify.app/.netlify/functions`

That URL change is only needed once.

### 3) Download the IPA
GitHub → **Actions** → **Build ZK Lead Radar IPA** → latest green run → **Artifacts** → `ZKLeadRadar-IPA`.

Download and unzip it. Install `ZKLeadRadar.ipa` with SideStore in the same way as your existing sideloaded apps.

## Future updates

Future workflow is simply:

1. Replace/update files in this same GitHub repo.
2. GitHub Actions builds a new IPA automatically.
3. Netlify automatically redeploys the live API/form from the same commit.
4. Download the new IPA from Actions and install it as an update.

Keep `PRODUCT_BUNDLE_IDENTIFIER` as `com.zk.leadradar` so SideStore sees new builds as updates to the same app.

## Live lead rules in v1

A lead shown in the app must:

- be less than 24 hours old;
- have the customer's explicit confirmation that they still need a contractor;
- not be marked assigned;
- not be marked sold;
- not match a recent duplicate fingerprint.

The form/API does **not** claim a phone number is verified unless a future verification service actually verifies it. `phoneVerified` is false in this first build.

Real leads only appear when real people submit the form or a future permitted lead source is connected. There are no demo leads bundled into the app.

## Verified-lead gate

The live feed now refuses to label a submission as verified from a checkbox alone. A lead is visible in the iPhone app only when:

- it is less than 24 hours old;
- its phone number has passed an SMS one-time-code check;
- the customer re-confirms the job is still open during OTP verification;
- that open confirmation is less than 6 hours old;
- it is not a duplicate of the same phone/postcode/category/job within 7 days;
- it is not assigned or sold.

Phone OTP uses Twilio Verify. Set these Netlify environment variables once: `TWILIO_ACCOUNT_SID`, `TWILIO_AUTH_TOKEN`, `TWILIO_VERIFY_SERVICE_SID`. If they are absent, submissions can be stored but **will never appear as verified live leads**.

This deliberately fails closed rather than showing unverified or invented jobs.
