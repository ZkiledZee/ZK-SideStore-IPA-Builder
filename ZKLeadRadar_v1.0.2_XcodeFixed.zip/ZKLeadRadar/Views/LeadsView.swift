import SwiftUI

struct LeadsView: View {
    @EnvironmentObject var store: LeadStore
    var body: some View {
        NavigationStack {
            List(store.filteredLeads) { lead in
                LeadRow(lead: lead).listRowBackground(Color.clear).listRowSeparator(.hidden)
            }
            .listStyle(.plain)
            .scrollContentBackground(.hidden)
            .background(Color.zkInk)
            .navigationTitle("Live Leads")
            .toolbar { Button { Task { await store.refresh() } } label: { Image(systemName: "arrow.clockwise") } }
            .overlay {
                if store.filteredLeads.isEmpty { ContentUnavailableView("No verified open leads", systemImage: "scope", description: Text(store.errorMessage ?? "Scanning live sources")) }
            }
        }
    }
}
