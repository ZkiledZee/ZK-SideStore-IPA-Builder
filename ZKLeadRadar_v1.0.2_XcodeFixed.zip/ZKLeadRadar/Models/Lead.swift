import Foundation
import CoreLocation

struct Lead: Identifiable, Codable, Hashable {
    let id: String
    let title: String
    let category: String
    let city: String
    let postcode: String?
    let latitude: Double
    let longitude: Double
    let createdAt: Date
    let estimatedMin: Int?
    let estimatedMax: Int?
    let contactName: String?
    let phone: String?
    let email: String?
    let source: String?
    let phoneVerified: Bool
    let customerConfirmedOpen: Bool
    let contractorAssigned: Bool
    let duplicate: Bool
    let sold: Bool
    let contactVerified: Bool?
    let openConfirmedAt: Date?
    let verification: String?

    var coordinate: CLLocationCoordinate2D { .init(latitude: latitude, longitude: longitude) }

    var isFresh: Bool { Date().timeIntervalSince(createdAt) < 86_400 }

    var isVerifiedOpen: Bool {
        let recentConfirmation = openConfirmedAt.map { Date().timeIntervalSince($0) < 21_600 } ?? false
        return isFresh && phoneVerified && (contactVerified ?? false) && recentConfirmation && customerConfirmedOpen && !contractorAssigned && !duplicate && !sold
    }

    var score: Int {
        var value = 35
        if isFresh { value += 20 }
        if customerConfirmedOpen { value += 20 }
        if phoneVerified { value += 15 }
        if !duplicate { value += 5 }
        if !contractorAssigned { value += 5 }
        return min(value, 100)
    }

    var ageText: String {
        let mins = max(1, Int(Date().timeIntervalSince(createdAt) / 60))
        if mins < 60 { return "\(mins)m ago" }
        let hours = mins / 60
        if hours < 24 { return "\(hours)h ago" }
        return "\(hours / 24)d ago"
    }

    var valueText: String? {
        guard let min = estimatedMin, let max = estimatedMax else { return nil }
        return "£\(min.formatted())–£\(max.formatted())"
    }
}

struct LeadEnvelope: Codable {
    let leads: [Lead]
    let generatedAt: Date?
}
