import SwiftUI

@MainActor
final class LeadStore: ObservableObject {
    @Published private(set) var leads: [Lead] = []
    @Published private(set) var isLoading = false
    @Published private(set) var lastUpdated: Date?
    @Published var errorMessage: String?
    @Published var selectedCity = "All Areas"

    private var refreshTask: Task<Void, Never>?

    var openLeads: [Lead] {
        leads.filter { $0.isVerifiedOpen }
    }

    var filteredLeads: [Lead] {
        let base = openLeads.sorted { $0.createdAt > $1.createdAt }
        guard selectedCity != "All Areas" else { return base }
        return base.filter { $0.city.caseInsensitiveCompare(selectedCity) == .orderedSame }
    }

    var verifiedToday: Int {
        let calendar = Calendar.current
        return openLeads.filter { calendar.isDateInToday($0.createdAt) }.count
    }

    var newLeadCount: Int {
        openLeads.filter { Date().timeIntervalSince($0.createdAt) < 3_600 }.count
    }

    func start() {
        guard refreshTask == nil else { return }
        refreshTask = Task { [weak self] in
            while !Task.isCancelled {
                await self?.refresh()
                try? await Task.sleep(nanoseconds: 45_000_000_000)
            }
        }
    }

    func stop() {
        refreshTask?.cancel()
        refreshTask = nil
    }

    func refresh() async {
        if leads.isEmpty { isLoading = true }
        defer { isLoading = false }

        do {
            let result = try await APIClient.shared.fetchLeads()
            leads = result
            lastUpdated = Date()
            errorMessage = nil
        } catch {
            errorMessage = error.localizedDescription
        }
    }
}
