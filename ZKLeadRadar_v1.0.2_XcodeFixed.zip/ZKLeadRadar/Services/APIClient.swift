import Foundation

actor APIClient {
    static let shared = APIClient()

    private var baseURL: URL? {
        guard let raw = Bundle.main.object(forInfoDictionaryKey: "LIVE_API_BASE_URL") as? String,
              !raw.contains("YOUR-SITE"),
              let url = URL(string: raw) else { return nil }
        return url
    }

    enum APIError: LocalizedError {
        case notConfigured
        case invalidResponse
        case server(Int)

        var errorDescription: String? {
            switch self {
            case .notConfigured: return "Live backend not configured yet."
            case .invalidResponse: return "The live lead service returned an invalid response."
            case .server(let code): return "Lead service error (HTTP \(code))."
            }
        }
    }

    func fetchLeads() async throws -> [Lead] {
        guard let baseURL else { throw APIError.notConfigured }
        let url = baseURL.appendingPathComponent("leads")
        var request = URLRequest(url: url)
        request.cachePolicy = .reloadIgnoringLocalCacheData
        request.timeoutInterval = 15
        request.setValue("application/json", forHTTPHeaderField: "Accept")

        let (data, response) = try await URLSession.shared.data(for: request)
        guard let http = response as? HTTPURLResponse else { throw APIError.invalidResponse }
        guard (200..<300).contains(http.statusCode) else { throw APIError.server(http.statusCode) }

        let decoder = JSONDecoder()
        decoder.dateDecodingStrategy = .iso8601
        if let envelope = try? decoder.decode(LeadEnvelope.self, from: data) {
            return envelope.leads
        }
        return try decoder.decode([Lead].self, from: data)
    }
}
