import SwiftUI

struct BuyersView: View {
    var body: some View {
        NavigationStack {
            VStack(spacing: 18) {
                Image(systemName: "person.2.badge.gearshape.fill").font(.system(size: 54)).foregroundStyle(Color.zkCyan)
                Text("Buyer Network").font(.title.bold())
                Text("This build keeps buyer matching separate from lead discovery. Connect your CRM/backend to assign one exclusive contractor per area and trade.")
                    .multilineTextAlignment(.center).foregroundStyle(.secondary)
            }
            .padding(28).frame(maxWidth: .infinity, maxHeight: .infinity)
            .background(Color.zkInk).navigationTitle("Buyers")
        }
    }
}
