import SwiftUI

extension Color {
    static let zkCyan = Color(red: 0.02, green: 0.94, blue: 0.92)
    static let zkBlue = Color(red: 0.05, green: 0.48, blue: 1.0)
    static let zkPanel = Color(red: 0.018, green: 0.055, blue: 0.085)
    static let zkInk = Color(red: 0.004, green: 0.018, blue: 0.032)
}

struct NeonPanel<Content: View>: View {
    private let content: Content

    init(@ViewBuilder content: () -> Content) {
        self.content = content()
    }

    var body: some View {
        content
            .padding(14)
            .background(
                RoundedRectangle(cornerRadius: 18, style: .continuous)
                    .fill(Color.zkPanel.opacity(0.88))
            )
            .overlay(
                RoundedRectangle(cornerRadius: 18, style: .continuous)
                    .stroke(Color.zkCyan.opacity(0.20), lineWidth: 1)
            )
    }
}

struct LivePill: View {
    let online: Bool

    var body: some View {
        HStack(spacing: 7) {
            Circle()
                .fill(online ? Color.zkCyan : Color.orange)
                .frame(width: 8, height: 8)
                .shadow(color: online ? Color.zkCyan : Color.orange, radius: 7)
            Text(online ? "LIVE" : "CONNECT")
                .font(.caption.bold())
                .foregroundStyle(.white)
        }
        .padding(.horizontal, 13)
        .padding(.vertical, 8)
        .background(Color.white.opacity(0.035), in: Capsule())
        .overlay(Capsule().stroke(Color.zkCyan.opacity(0.34), lineWidth: 1))
    }
}

struct ZKMark: View {
    var body: some View {
        ZStack {
            Circle().stroke(Color.zkCyan.opacity(0.9), lineWidth: 2)
            Circle().stroke(Color.zkCyan.opacity(0.35), lineWidth: 1).padding(6)
            Path { p in
                p.move(to: CGPoint(x: 20, y: 5))
                p.addLine(to: CGPoint(x: 20, y: 35))
                p.move(to: CGPoint(x: 5, y: 20))
                p.addLine(to: CGPoint(x: 35, y: 20))
            }
            .stroke(Color.zkCyan.opacity(0.35), lineWidth: 1)
            Text("ZK")
                .font(.system(size: 14, weight: .black, design: .rounded))
                .foregroundStyle(.white)
        }
        .frame(width: 40, height: 40)
        .shadow(color: Color.zkCyan.opacity(0.45), radius: 8)
    }
}
