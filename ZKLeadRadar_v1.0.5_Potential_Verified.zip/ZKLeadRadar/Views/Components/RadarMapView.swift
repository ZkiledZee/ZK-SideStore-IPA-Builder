import SwiftUI
import MapKit

struct RadarMapView: View {
    let leads: [Lead]

    private let cityPoints: [(String, CLLocationCoordinate2D)] = [
        ("Bradford", .init(latitude: 53.795, longitude: -1.759)),
        ("Leeds", .init(latitude: 53.8008, longitude: -1.5491)),
        ("Halifax", .init(latitude: 53.725, longitude: -1.863)),
        ("Huddersfield", .init(latitude: 53.6458, longitude: -1.7850)),
        ("Wakefield", .init(latitude: 53.6833, longitude: -1.4977)),
        ("Ilkley", .init(latitude: 53.9245, longitude: -1.8233))
    ]

    @State private var position: MapCameraPosition = .region(
        MKCoordinateRegion(
            center: CLLocationCoordinate2D(latitude: 53.77, longitude: -1.69),
            span: MKCoordinateSpan(latitudeDelta: 0.58, longitudeDelta: 0.72)
        )
    )

    var body: some View {
        ZStack {
            Map(position: $position, interactionModes: [.pan, .zoom]) {
                ForEach(cityPoints, id: \.0) { item in
                    Annotation(item.0, coordinate: item.1) {
                        VStack(spacing: 3) {
                            ZStack {
                                Circle().fill(Color.zkCyan.opacity(0.18)).frame(width: 28, height: 28)
                                Circle().stroke(Color.zkCyan.opacity(0.95), lineWidth: 1.5).frame(width: 18, height: 18)
                                Circle().fill(Color.white).frame(width: 5, height: 5)
                            }
                            .shadow(color: Color.zkCyan, radius: 8)
                            Text(item.0)
                                .font(.system(size: 10, weight: .semibold))
                                .foregroundStyle(.white)
                                .padding(.horizontal, 5)
                                .padding(.vertical, 2)
                                .background(Color.black.opacity(0.62), in: Capsule())
                        }
                    }
                }

                ForEach(leads) { lead in
                    Annotation(lead.title, coordinate: lead.coordinate) {
                        ZStack {
                            Circle().fill(Color.zkBlue.opacity(0.25)).frame(width: 30, height: 30)
                            Circle().stroke(Color.zkBlue, lineWidth: 2).frame(width: 20, height: 20)
                            Circle().fill(Color.white).frame(width: 6, height: 6)
                        }
                        .shadow(color: Color.zkBlue, radius: 10)
                    }
                }
            }
            .mapStyle(.standard(elevation: .flat, pointsOfInterest: .excludingAll, showsTraffic: false))
            .saturation(0.15)
            .contrast(1.18)
            .colorMultiply(Color(red: 0.22, green: 0.66, blue: 0.82))

        }
        .clipShape(RoundedRectangle(cornerRadius: 18, style: .continuous))
        .overlay(
            RoundedRectangle(cornerRadius: 18, style: .continuous)
                .stroke(Color.zkCyan.opacity(0.28), lineWidth: 1)
        )
    }
}
