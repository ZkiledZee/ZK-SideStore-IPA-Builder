import SwiftUI

struct LeadRow: View {
    let lead: Lead

    private var icon: String {
        let category = lead.category.lowercased()
        if category.contains("roof") { return "house.fill" }
        if category.contains("heat") || category.contains("boiler") { return "flame.fill" }
        if category.contains("drain") || category.contains("plumb") { return "drop.fill" }
        if category.contains("electric") { return "bolt.fill" }
        return "wrench.and.screwdriver.fill"
    }

    var body: some View {
        HStack(spacing: 11) {
            ZStack {
                Circle().fill(Color.zkCyan.opacity(0.11)).frame(width: 48, height: 48)
                Circle().stroke(Color.zkCyan.opacity(0.55), lineWidth: 1).frame(width: 48, height: 48)
                Image(systemName: icon).font(.system(size: 21, weight: .semibold)).foregroundStyle(Color.zkCyan)
            }
            .shadow(color: Color.zkCyan.opacity(0.2), radius: 8)

            VStack(alignment: .leading, spacing: 4) {
                Text("\(lead.title) - \(lead.city)")
                    .font(.system(size: 14, weight: .bold))
                    .foregroundStyle(.white)
                    .lineLimit(1)

                Text(lead.ageText)
                    .font(.system(size: 10))
                    .foregroundStyle(Color.white.opacity(0.58))

                Label(lead.statusTitle, systemImage: lead.statusIcon)
                    .font(.system(size: 10, weight: .semibold))
                    .foregroundStyle(lead.isVerifiedOpen ? Color.zkCyan : Color.orange)
            }

            Spacer(minLength: 6)

            VStack(alignment: .trailing, spacing: 7) {
                if let value = lead.valueText {
                    Text(value)
                        .font(.system(size: 10, weight: .medium))
                        .foregroundStyle(Color.zkCyan.opacity(0.90))
                        .padding(.horizontal, 8)
                        .padding(.vertical, 5)
                        .background(Color.zkCyan.opacity(0.06), in: Capsule())
                        .overlay(Capsule().stroke(Color.zkCyan.opacity(0.18)))
                }
                Text("\(lead.score)")
                    .font(.system(size: 19, weight: .bold, design: .rounded))
                    .foregroundStyle(Color.zkCyan)
            }
        }
        .padding(11)
        .background(Color.zkPanel.opacity(0.75), in: RoundedRectangle(cornerRadius: 14, style: .continuous))
        .overlay(RoundedRectangle(cornerRadius: 14, style: .continuous).stroke(Color.zkCyan.opacity(0.15), lineWidth: 1))
    }
}
