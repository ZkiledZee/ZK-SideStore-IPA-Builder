import SwiftUI

struct RadarView: View {
    @EnvironmentObject var store: LeadStore
    var body: some View {
        VStack(spacing: 14) {
            HStack {
                VStack(alignment: .leading) {
                    Text("Live Radar").font(.largeTitle.bold())
                    Text("Tap and zoom the real map").font(.caption).foregroundStyle(.secondary)
                }
                Spacer()
                LivePill(online: store.lastUpdated != nil && store.errorMessage == nil)
            }
            RadarMapView(leads: store.filteredLeads).frame(maxHeight: .infinity)
            HStack {
                Text("\(store.filteredLeads.count) verified open")
                Spacer()
                Text("Refreshes every 45s")
            }.font(.caption).foregroundStyle(.secondary)
        }
        .padding().background(Color.zkInk.ignoresSafeArea())
    }
}
