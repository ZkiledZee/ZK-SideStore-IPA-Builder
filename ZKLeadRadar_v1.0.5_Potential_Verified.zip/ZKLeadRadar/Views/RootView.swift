import SwiftUI

struct RootView: View {
    @State private var tab = 0

    var body: some View {
        ZStack(alignment: .bottom) {
            Group {
                switch tab {
                case 1: LeadsView()
                case 2: RadarView()
                case 3: BuyersView()
                case 4: SettingsView()
                default: HomeView(selectedTab: $tab)
                }
            }
            .frame(maxWidth: .infinity, maxHeight: .infinity)

            ZKBottomBar(selection: $tab)
        }
        .background(Color.zkInk.ignoresSafeArea())
    }
}

private struct ZKBottomBar: View {
    @Binding var selection: Int

    private let items: [(String, String)] = [
        ("Home", "house.fill"),
        ("Leads", "list.bullet"),
        ("Radar", "scope"),
        ("Buyers", "person.2.fill"),
        ("Settings", "gearshape.fill")
    ]

    var body: some View {
        HStack(spacing: 0) {
            ForEach(0..<items.count, id: \.self) { index in
                Button {
                    selection = index
                } label: {
                    VStack(spacing: 5) {
                        ZStack {
                            if index == 2 {
                                Circle()
                                    .stroke(Color.zkCyan.opacity(0.9), lineWidth: 2)
                                    .frame(width: 43, height: 43)
                                    .shadow(color: Color.zkBlue.opacity(0.8), radius: 9)
                                Circle()
                                    .stroke(Color.zkBlue.opacity(0.45), lineWidth: 1)
                                    .frame(width: 33, height: 33)
                            }
                            Image(systemName: items[index].1)
                                .font(.system(size: index == 2 ? 20 : 18, weight: .semibold))
                                .foregroundStyle(selection == index || index == 2 ? Color.zkCyan : Color.white.opacity(0.65))
                        }
                        .frame(height: 32)

                        Text(items[index].0)
                            .font(.system(size: 10, weight: .medium))
                            .foregroundStyle(selection == index ? Color.zkCyan : Color.white.opacity(0.72))
                    }
                    .frame(maxWidth: .infinity)
                    .contentShape(Rectangle())
                }
                .buttonStyle(.plain)
            }
        }
        .padding(.horizontal, 8)
        .padding(.top, 10)
        .padding(.bottom, 8)
        .background(
            RoundedRectangle(cornerRadius: 20, style: .continuous)
                .fill(Color(red: 0.012, green: 0.045, blue: 0.07).opacity(0.98))
        )
        .overlay(
            RoundedRectangle(cornerRadius: 20, style: .continuous)
                .stroke(Color.zkCyan.opacity(0.22), lineWidth: 1)
        )
        .padding(.horizontal, 12)
        .padding(.bottom, 4)
    }
}
