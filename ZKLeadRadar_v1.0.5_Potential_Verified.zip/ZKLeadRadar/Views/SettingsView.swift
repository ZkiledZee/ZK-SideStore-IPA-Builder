import SwiftUI

struct SettingsView: View {
    @EnvironmentObject var store: LeadStore
    var body: some View {
        NavigationStack {
            Form {
                Section("Live service") {
                    LabeledContent("Status", value: store.errorMessage == nil && store.lastUpdated != nil ? "Connected" : "Not connected")
                    if let date = store.lastUpdated { LabeledContent("Last sync", value: date.formatted(date: .omitted, time: .standard)) }
                    if let error = store.errorMessage { Text(error).foregroundStyle(.orange) }
                    Button("Refresh now") { Task { await store.refresh() } }
                }
                Section("Verification rules") {
                    Label("Fresh: under 24 hours", systemImage: "clock.badge.checkmark")
                    Label("Customer confirms job is still open", systemImage: "person.crop.circle.badge.checkmark")
                    Label("No contractor assigned", systemImage: "xmark.circle")
                    Label("Duplicate filtered", systemImage: "square.on.square.dashed")
                    Label("Sold leads hidden", systemImage: "lock.fill")
                }
                Section("Important") {
                    Text("Phone verified is only shown when your backend has genuinely completed a phone verification step. The app never guesses that status.")
                }
            }
            .scrollContentBackground(.hidden).background(Color.zkInk).navigationTitle("Settings")
        }
    }
}
