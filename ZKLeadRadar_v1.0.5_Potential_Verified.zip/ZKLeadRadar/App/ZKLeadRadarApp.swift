import SwiftUI

@main
struct ZKLeadRadarApp: App {
    @StateObject private var store = LeadStore()

    var body: some Scene {
        WindowGroup {
            RootView()
                .environmentObject(store)
                .preferredColorScheme(.dark)
        }
    }
}
