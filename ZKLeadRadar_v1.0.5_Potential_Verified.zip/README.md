# ZK Lead Radar v1.0.5

Real SwiftUI iPhone app for West Yorkshire lead generation.

## Lead states
- **Potential**: fresh discovered/submitted opportunity that is not sold, duplicated, or assigned, but has not yet passed customer verification.
- **Verified Live**: fresh lead with verified contact details and a customer confirmation within the last 6 hours that they still need a contractor.

The app does not inject demo leads. If the backend is empty or offline, it shows an empty/offline state rather than fake jobs.

## Backend
Netlify functions are included in `netlify/functions` and a customer submission/verification form is in `web/index.html`.

## Bundle ID
`com.zk.leadradar`
