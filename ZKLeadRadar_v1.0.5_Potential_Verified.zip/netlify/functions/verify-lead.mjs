import { leadStore, json, twilioConfigured, twilioVerify } from './_store.mjs';

export default async (req) => {
  if (req.method === 'OPTIONS') return new Response(null, { status: 204, headers: { 'access-control-allow-origin': '*', 'access-control-allow-headers': 'content-type' } });
  if (req.method !== 'POST') return json({ error: 'Method not allowed' }, 405);

  try {
    const body = await req.json();
    const id = String(body.id ?? '').trim();
    const code = String(body.code ?? '').replace(/\D/g, '').slice(0, 10);
    if (!id || code.length < 4) return json({ error: 'Enter the verification code.' }, 400);
    if (!twilioConfigured()) return json({ error: 'Phone verification is not configured yet.' }, 503);

    const store = leadStore();
    const record = await store.get(`lead/${id}`, { type: 'json', consistency: 'strong' });
    if (!record) return json({ error: 'Lead not found.' }, 404);
    if (record.duplicate || record.sold || record.contractorAssigned) return json({ error: 'This request is no longer eligible.' }, 409);

    const check = await twilioVerify('VerificationCheck', { To: record.phone, Code: code });
    if (check.status !== 'approved') return json({ error: 'That code was not accepted.' }, 400);

    const now = new Date().toISOString();
    record.phoneVerified = true;
    record.contactVerified = true;
    record.customerConfirmedOpen = true;
    record.openConfirmedAt = now;
    record.updatedAt = now;
    record.verification = 'verified-open';
    await store.setJSON(`lead/${id}`, record, { metadata: { createdAt: record.createdAt, city: record.city, category: record.category, verified: true } });

    return json({ ok: true, verified: true, openConfirmedAt: now });
  } catch (error) {
    return json({ error: error?.message || 'Unable to verify this request.' }, 500);
  }
};
