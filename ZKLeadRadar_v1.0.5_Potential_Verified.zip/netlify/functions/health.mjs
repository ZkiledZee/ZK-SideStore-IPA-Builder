import { json } from './_store.mjs';
export default async () => json({ ok: true, service: 'ZK Lead Radar', storage: 'Netlify Blobs', time: new Date().toISOString() });
