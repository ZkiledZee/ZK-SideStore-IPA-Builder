import { leadStore, json } from './_store.mjs';

const DAY = 86_400_000;
const OPEN_VERIFICATION_WINDOW = 6 * 60 * 60 * 1000;

export default async (req) => {
  if (req.method !== 'GET') return json({ error: 'Method not allowed' }, 405);

  try {
    const store = leadStore();
    const { blobs } = await store.list({ prefix: 'lead/' });
    const now = Date.now();
    const cutoff = now - DAY;
    const openCutoff = now - OPEN_VERIFICATION_WINDOW;

    const records = await Promise.all(
      blobs.slice(-500).map(({ key }) => store.get(key, { type: 'json', consistency: 'strong' }))
    );

    const leads = records
      .filter(Boolean)
      .filter(x => Date.parse(x.createdAt) >= cutoff)
      .filter(x => x.contractorAssigned !== true && x.duplicate !== true && x.sold !== true)
      .sort((a, b) => Date.parse(b.openConfirmedAt || b.createdAt) - Date.parse(a.openConfirmedAt || a.createdAt))
      .slice(0, 250)
      .map(x => {
        const verified = x.phoneVerified === true && x.contactVerified === true &&
          x.customerConfirmedOpen === true && Date.parse(x.openConfirmedAt || 0) >= openCutoff;
        return {
          ...x,
          phone: verified ? x.phone : null,
          email: verified ? x.email : null,
          contactName: verified ? x.contactName : null,
          publicToken: undefined
        };
      });

    return json({ leads, generatedAt: new Date().toISOString(), live: true, verificationWindowHours: 6 });
  } catch (error) {
    return json({ error: error?.message || 'Unable to load leads.' }, 500);
  }
};
