import crypto from 'node:crypto';
import { leadStore, fingerprintStore, json, cleanPhone, twilioConfigured, twilioVerify } from './_store.mjs';

const DAY = 86_400_000;
const text = (value, max = 180) => String(value ?? '').trim().slice(0, max);

function finiteNumber(value) {
  const n = Number(value);
  return Number.isFinite(n) ? n : null;
}

export default async (req) => {
  if (req.method === 'OPTIONS') return new Response(null, { status: 204, headers: { 'access-control-allow-origin': '*', 'access-control-allow-headers': 'content-type' } });
  if (req.method !== 'POST') return json({ error: 'Method not allowed' }, 405);

  try {
    const body = await req.json();
    const title = text(body.title);
    const category = text(body.category, 80);
    const city = text(body.city, 80);
    const postcode = text(body.postcode, 16).toUpperCase();
    const phone = cleanPhone(body.phone);
    const email = text(body.email, 160).toLowerCase();
    const latitude = finiteNumber(body.latitude);
    const longitude = finiteNumber(body.longitude);

    if (!title || !category || !city || latitude === null || longitude === null || body.customerConfirmedOpen !== true) {
      return json({ error: 'Please complete the job, area and location and confirm you still need a contractor.' }, 400);
    }
    if (!phone) return json({ error: 'A mobile number is required so we can verify the request before showing it as a live lead.' }, 400);

    const normalizedJob = title.toLowerCase().replace(/\s+/g, ' ').slice(0, 120);
    const fingerprint = crypto.createHash('sha256')
      .update(`${phone}|${postcode}|${category.toLowerCase()}|${normalizedJob}`)
      .digest('hex');

    const fingerprints = fingerprintStore();
    const previous = await fingerprints.get(fingerprint, { type: 'json', consistency: 'strong' });
    const duplicate = Boolean(previous?.createdAt && Date.now() - Date.parse(previous.createdAt) < 7 * DAY);

    if (duplicate) return json({ ok: true, duplicate: true, message: 'We already have this recent request.' }, 200);

    const id = crypto.randomUUID();
    const publicToken = crypto.randomBytes(24).toString('hex');
    const createdAt = new Date().toISOString();
    const record = {
      id,
      createdAt,
      updatedAt: createdAt,
      title,
      category,
      city,
      postcode: postcode || null,
      latitude,
      longitude,
      estimatedMin: finiteNumber(body.estimatedMin),
      estimatedMax: finiteNumber(body.estimatedMax),
      contactName: text(body.contactName, 100) || null,
      phone,
      email: email || null,
      source: 'direct-form',
      phoneVerified: false,
      contactVerified: false,
      customerConfirmedOpen: true,
      openConfirmedAt: null,
      contractorAssigned: false,
      duplicate: false,
      sold: false,
      publicToken,
      verification: twilioConfigured() ? 'otp-sent' : 'verification-unavailable'
    };

    await leadStore().setJSON(`lead/${id}`, record, { metadata: { createdAt, city, category, duplicate: false } });
    await fingerprints.setJSON(fingerprint, { createdAt, leadId: id });

    if (!twilioConfigured()) {
      return json({ ok: true, id, duplicate: false, verificationRequired: true, verificationAvailable: false,
        message: 'Request saved, but phone verification is not configured yet so it will not appear as a verified live lead.' }, 202);
    }

    try {
      await twilioVerify('Verifications', { To: phone, Channel: 'sms' });
    } catch (error) {
      record.verification = 'otp-send-failed';
      record.updatedAt = new Date().toISOString();
      await leadStore().setJSON(`lead/${id}`, record, { metadata: { createdAt, city, category, duplicate: false } });
      return json({ error: error?.message || 'Could not send verification code.', id }, 502);
    }

    return json({ ok: true, id, duplicate: false, verificationRequired: true, verificationAvailable: true,
      message: 'We sent a verification code to your phone.' }, 201);
  } catch (error) {
    return json({ error: error?.message || 'Unable to save lead.' }, 500);
  }
};
